#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                      🚀 CRYPTO TRADING BOT - LAUNCHER 🚀                      ║
║                                                                               ║
║  Запускатель для умного крипто-торгового бота                                ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

import sys
import asyncio
import argparse
import signal
from datetime import datetime

# Импортируем модули бота
from crypto_bot import CryptoTradingBot
from config import config, print_config, update_config

# Глобальная переменная для бота
bot = None

def signal_handler(sig, frame):
    """Обработчик сигнала остановки"""
    print("\n\n🛑 Получен сигнал остановки...")
    if bot:
        bot.stop()
    print("👋 До свидания!")
    sys.exit(0)

# Регистрируем обработчики сигналов
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

def print_banner():
    """Вывести баннер"""
    banner = """
╔═══════════════════════════════════════════════════════════════════════════════╗
║                                                                               ║
║     ██╗   ██╗██╗  ████████╗██╗███╗   ███╗ █████╗ ████████╗███████╗            ║
║     ██║   ██║██║  ╚══██╔══╝██║████╗ ████║██╔══██╗╚══██╔══╝██╔════╝            ║
║     ██║   ██║██║     ██║   ██║██╔████╔██║███████║   ██║   █████╗              ║
║     ██║   ██║██║     ██║   ██║██║╚██╔╝██║██╔══██║   ██║   ██╔══╝              ║
║     ╚██████╔╝███████╗██║   ██║██║ ╚═╝ ██║██║  ██║   ██║   ███████╗            ║
║      ╚═════╝ ╚══════╝╚═╝   ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝   ╚══════╝            ║
║                                                                               ║
║              ██████╗██████╗ ██╗   ██╗██████╗ ████████╗ ██████╗                ║
║             ██╔════╝██╔══██╗╚██╗ ██╔╝██╔══██╗╚══██╔══╝██╔═══██╗               ║
║             ██║     ██████╔╝ ╚████╔╝ ██████╔╝   ██║   ██║   ██║               ║
║             ██║     ██╔══██╗  ╚██╔╝  ██╔═══╝    ██║   ██║   ██║               ║
║             ╚██████╗██║  ██║   ██║   ██║        ██║   ╚██████╔╝               ║
║              ╚═════╝╚═╝  ╚═╝   ╚═╝   ╚═╝        ╚═╝    ╚═════╝                ║
║                                                                               ║
║                    🤖 ULTIMATE CRYPTO TRADING BOT 🤖                          ║
║                                                                               ║
║  Возможности:                                                                 ║
║  ✅ Мониторинг 100+ криптовалют в реальном времени                           ║
║  ✅ Технический анализ (RSI, MACD, Bollinger Bands, EMA)                    ║
║  ✅ AI-предсказания и паттерн-рекогниция                                      ║
║  ✅ Проверка токенов на скам (Honeypot, Rug Pull)                           ║
║  ✅ Сигналы на покупку/продажу с уровнями входа/выхода                      ║
║  ✅ Risk Management (Stop-Loss, Take-Profit, Trailing Stop)                 ║
║  ✅ Управление портфелем и подсчет P&L                                      ║
║  ✅ Telegram уведомления в реальном времени                                  ║
║  ✅ DEX сканер для новых токенов                                            ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
    """
    print(banner)

def print_menu():
    """Вывести меню"""
    menu = """
📋 ДОСТУПНЫЕ КОМАНДЫ:

  1. 🚀 Запустить бота          - Начать мониторинг и торговлю
  2. ⚙️  Показать настройки     - Вывести текущую конфигурацию
  3. 🔧 Изменить настройки      - Изменить параметры торговли
  4. 📊 Тест AI анализатора     - Протестировать предсказания
  5. 🔍 Тест DEX сканера        - Проверить DEX сканер
  6. 💰 Проверить портфель      - Показать текущий портфель
  7. ❓ Помощь                  - Показать справку
  0. 🚪 Выход                   - Завершить работу

"""
    print(menu)

def test_ai_analyzer():
    """Тест AI анализатора"""
    print("\n🧠 Тестирование AI анализатора...")
    
    try:
        import numpy as np
        import pandas as pd
        from ai_analyzer import Predictor
        
        # Создаем тестовые данные
        np.random.seed(42)
        n = 100
        
        trend = np.linspace(100, 120, n)
        noise = np.random.randn(n) * 2
        prices = trend + noise
        
        df = pd.DataFrame({
            'open': prices + np.random.randn(n) * 0.5,
            'high': prices + abs(np.random.randn(n)) * 2,
            'low': prices - abs(np.random.randn(n)) * 2,
            'close': prices,
            'volume': np.random.randint(1000, 10000, n)
        })
        
        predictor = Predictor()
        prediction = predictor.predict(df)
        
        print("\n" + "=" * 50)
        print("🧠 AI PREDICTION RESULT")
        print("=" * 50)
        print(f"📊 Направление: {prediction.direction}")
        print(f"🎯 Уверенность: {prediction.confidence:.1f}%")
        print(f"💰 Целевая цена: ${prediction.target_price:.2f}")
        print(f"📈 Вероятность UP: {prediction.probability_up:.1f}%")
        print(f"📉 Вероятность DOWN: {prediction.probability_down:.1f}%")
        print(f"➡️  Вероятность SIDEWAYS: {prediction.probability_sideways:.1f}%")
        print("\n🔑 Ключевые уровни:")
        for level, value in prediction.key_levels.items():
            print(f"   {level}: ${value:.2f}")
        print("\n💡 Обоснование:")
        for reason in prediction.reasoning:
            print(f"   • {reason}")
        print("=" * 50 + "\n")
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")

def test_dex_scanner():
    """Тест DEX сканера"""
    print("\n🔍 Тестирование DEX сканера...")
    
    try:
        from dex_scanner import DexScreenerScanner
        
        scanner = DexScreenerScanner()
        
        # Поиск AI токенов
        print("\n🔍 Поиск AI токенов...")
        ai_pairs = scanner.search_pairs("AI")
        
        print(f"\n✅ Найдено {len(ai_pairs)} пар\n")
        
        for i, pair in enumerate(ai_pairs[:5], 1):
            print(f"{i}. 💎 {pair.token0_symbol}/{pair.token1_symbol}")
            print(f"   💰 Цена: ${pair.price_usd:.6f}")
            print(f"   📈 Изменение 24ч: {pair.price_change_24h:+.2f}%")
            print(f"   📊 Объем 24ч: ${pair.volume_24h:,.0f}")
            print(f"   💧 Ликвидность: ${pair.liquidity_usd:,.0f}")
            print(f"   🔄 Покупок/Продаж: {pair.buyers_24h}/{pair.sellers_24h}")
            print(f"   ⭐ Buy/Sell Ratio: {pair.buy_sell_ratio:.2f}")
            print()
        
        # Проверка на скам
        if ai_pairs:
            from dex_scanner import LiquidityMonitor
            monitor = LiquidityMonitor(scanner)
            
            print("\n🛡️ Проверка на скам для первого токена:")
            risk = monitor.check_rug_pull_risk(ai_pairs[0])
            print(f"   Risk Score: {risk['risk_score']}/100")
            print(f"   Risk Level: {risk['risk_level']}")
            print(f"   Suspicious: {'ДА' if risk['is_suspicious'] else 'НЕТ'}")
            print("   Факторы риска:")
            for factor in risk['risk_factors']:
                print(f"      • {factor}")
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")

def check_portfolio():
    """Проверить портфель"""
    print("\n💰 Проверка портфеля...")
    
    try:
        from crypto_bot import PortfolioManager
        
        pm = PortfolioManager()
        summary = pm.get_summary()
        
        print("\n" + "=" * 50)
        print("📊 СВОДКА ПОРТФЕЛЯ")
        print("=" * 50)
        print(f"💰 Общая стоимость: ${summary['total_value']:.2f}")
        print(f"💵 Доступно USDT: ${summary['available_usdt']:.2f}")
        print(f"📈 Нереализованный P&L: ${summary['unrealized_pnl']:+.2f}")
        print(f"💵 Реализованный P&L: ${summary['realized_pnl']:+.2f}")
        print(f"📊 Общий P&L: ${summary['total_pnl']:+.2f}")
        print(f"📋 Открытых позиций: {summary['open_positions']}")
        print(f"🏆 Win Rate: {summary['win_rate']:.1f}%")
        print(f"🔄 Всего сделок: {summary['total_trades']}")
        print("=" * 50 + "\n")
        
        if pm.portfolio.positions:
            print("📋 ОТКРЫТЫЕ ПОЗИЦИИ:")
            for symbol, pos in pm.portfolio.positions.items():
                pnl_pct = ((pos.current_price / pos.entry_price - 1) * 100) if pos.entry_price > 0 else 0
                print(f"\n   💎 {symbol}")
                print(f"      Количество: {pos.quantity:.6f}")
                print(f"      Вход: ${pos.entry_price:.6f}")
                print(f"      Текущая: ${pos.current_price:.6f}")
                print(f"      P&L: {pnl_pct:+.2f}% (${pos.unrealized_pnl:+.2f})")
                print(f"      Стоп-лосс: ${pos.stop_loss:.6f}")
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")

def change_settings():
    """Изменить настройки"""
    print("\n🔧 Изменение настроек:")
    print("\nДоступные параметры:")
    print("  - STOP_LOSS (%) - Стоп-лосс")
    print("  - TAKE_PROFIT_1 (%) - Первый тейк-профит")
    print("  - TAKE_PROFIT_2 (%) - Второй тейк-профит")
    print("  - MAX_POSITION_SIZE ($) - Максимальный размер позиции")
    print("  - SCAN_INTERVAL (сек) - Интервал сканирования")
    print("  - MIN_CONFIDENCE_BUY (%) - Минимальная уверенность для покупки")
    
    param = input("\nВведите название параметра: ").strip().upper()
    
    if not hasattr(config, param):
        print(f"❌ Неизвестный параметр: {param}")
        return
    
    value = input(f"Введите новое значение для {param}: ").strip()
    
    try:
        # Определяем тип текущего значения
        current = getattr(config, param)
        if isinstance(current, int):
            value = int(value)
        elif isinstance(current, float):
            value = float(value)
        elif isinstance(current, bool):
            value = value.lower() in ('true', 'yes', '1', 'да')
        
        update_config(**{param: value})
        print(f"✅ Параметр {param} обновлен!")
        
    except ValueError:
        print("❌ Неверный формат значения")

def show_help():
    """Показать справку"""
    help_text = """
╔═══════════════════════════════════════════════════════════════════════════════╗
║                              ❓ СПРАВКА                                        ║
╚═══════════════════════════════════════════════════════════════════════════════╝

📖 О БОТЕ:
   Это умный крипто-торговый бот, который использует технический анализ,
   AI-предсказания и проверку безопасности для поиска лучших торговых
   возможностей.

⚠️  ВАЖНО:
   • Этот бот предназначен для образовательных целей
   • Торговля криптовалютами связана с высокими рисками
   • Никогда не инвестируйте больше, чем готовы потерять
   • Всегда проводите собственный анализ (DYOR)

🔧 НАСТРОЙКИ:
   Перед запуском рекомендуется настроить:
   • STOP_LOSS - размер стоп-лосса (%)
   • TAKE_PROFIT - уровни фиксации прибыли (%)
   • MAX_POSITION_SIZE - максимальный размер позиции ($)
   • MIN_CONFIDENCE_BUY - минимальная уверенность для сигнала

📱 TELEGRAM:
   Бот отправляет уведомления о:
   • Торговых сигналах (покупка/продажа)
   • Достижении тейк-профитов
   • Срабатывании стоп-лоссов
   • Обновлениях портфеля

💡 СОВЕТЫ:
   • Начинайте с режима PAPER (тестовый)
   • Используйте небольшие позиции
   • Диверсифицируйте портфель
   • Следите за новостями рынка

"""
    print(help_text)

async def main():
    """Главная функция"""
    global bot
    
    print_banner()
    
    parser = argparse.ArgumentParser(description='Crypto Trading Bot')
    parser.add_argument('--mode', choices=['menu', 'direct'], default='menu',
                       help='Режим запуска')
    parser.add_argument('--config', action='store_true',
                       help='Показать конфигурацию')
    parser.add_argument('--test-ai', action='store_true',
                       help='Тест AI анализатора')
    parser.add_argument('--test-dex', action='store_true',
                       help='Тест DEX сканера')
    parser.add_argument('--portfolio', action='store_true',
                       help='Показать портфель')
    
    args = parser.parse_args()
    
    # Обработка аргументов командной строки
    if args.config:
        print_config()
        return
    
    if args.test_ai:
        test_ai_analyzer()
        return
    
    if args.test_dex:
        test_dex_scanner()
        return
    
    if args.portfolio:
        check_portfolio()
        return
    
    if args.mode == 'direct':
        # Прямой запуск бота
        print("🚀 Запуск бота...")
        print_config()
        
        bot = CryptoTradingBot()
        await bot.start()
        return
    
    # Интерактивное меню
    while True:
        print_menu()
        choice = input("Выберите действие (0-7): ").strip()
        
        if choice == '1':
            print("\n🚀 Запуск бота...")
            print_config()
            
            try:
                bot = CryptoTradingBot()
                await bot.start()
            except KeyboardInterrupt:
                print("\n\n🛑 Остановка бота...")
                if bot:
                    bot.stop()
            except Exception as e:
                print(f"\n❌ Ошибка: {e}")
                if bot:
                    bot.stop()
        
        elif choice == '2':
            print_config()
        
        elif choice == '3':
            change_settings()
        
        elif choice == '4':
            test_ai_analyzer()
        
        elif choice == '5':
            test_dex_scanner()
        
        elif choice == '6':
            check_portfolio()
        
        elif choice == '7':
            show_help()
        
        elif choice == '0':
            print("\n👋 До свидания! Удачной торговли! 🚀\n")
            break
        
        else:
            print("\n❌ Неверный выбор. Попробуйте снова.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n👋 До свидания!")
        sys.exit(0)
