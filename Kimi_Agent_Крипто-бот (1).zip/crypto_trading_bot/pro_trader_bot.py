#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    🚀 PRO TRADER BOT - ULTIMATE EDITION 🚀                    ║
║                                                                               ║
║  Полностью автономный торговый бот с интерактивными кнопками                 ║
║  • Интерактивные кнопки: Покупаю / Мониторю / Неинтересно                    ║
║  • Обновление сообщений в реальном времени                                   ║
║  • Закрепление активных сделок                                               ║
║  • Умная фильтрация (не показывать одно и то же)                             ║
║  • Вечный мониторинг без остановок                                           ║
║  • Отслеживание состояния каждого токена                                     ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

import sys
import os

# Fix Windows encoding
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')
    os.environ['PYTHONIOENCODING'] = 'utf-8'

import asyncio
import nest_asyncio
nest_asyncio.apply()

import requests
import json
import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field, asdict
from enum import Enum
import logging
from collections import defaultdict, deque
import threading
import signal

# Telegram
from telegram import Bot, Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, 
    ContextTypes, MessageHandler, filters
)

# Logging setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('pro_trader_bot.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

class Config:
    TG_TOKEN = "7813361546:AAGnQ49TEIoOCgBfrOFRXbB27PgMr56_nec"
    CHAT_ID = "-1003689936622"
    ADMIN_PASSWORD = "admin123"
    
    # Trading settings
    STOP_LOSS = 5
    TAKE_PROFIT_1 = 10
    TAKE_PROFIT_2 = 25
    TAKE_PROFIT_3 = 50
    MAX_POSITION_SIZE = 100
    
    # Signal filtering
    MIN_CONFIDENCE = 70
    MIN_VOLUME_24H = 200000
    SCAN_INTERVAL = 45
    
    # Token tracking
    IGNORE_DURATION_HOURS = 24
    WATCH_UPDATE_INTERVAL = 300  # 5 minutes

# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS AND DATA CLASSES
# ═══════════════════════════════════════════════════════════════════════════════

class TokenStatus(Enum):
    NEW = "new"
    WATCHING = "watching"
    BOUGHT = "bought"
    IGNORED = "ignored"
    SOLD = "sold"

class SignalType(Enum):
    STRONG_BUY = "STRONG_BUY"
    BUY = "BUY"
    SELL = "SELL"
    WATCH = "WATCH"

@dataclass
class TokenData:
    symbol: str
    name: str
    price: float
    price_change_1h: float = 0
    price_change_24h: float = 0
    volume_24h: float = 0
    market_cap: float = 0
    rank: int = 999

@dataclass
class TechnicalIndicators:
    rsi: float = 50
    macd: float = 0
    macd_signal: float = 0
    ema_20: float = 0
    ema_50: float = 0
    ema_200: float = 0
    trend: str = "NEUTRAL"
    volume_ratio: float = 1
    support: float = 0
    resistance: float = 0
    adx: float = 0

@dataclass
class TradingSignal:
    symbol: str
    signal_type: SignalType
    entry_price: float
    target_prices: List[float]
    stop_loss: float
    confidence: int
    indicators: TechnicalIndicators
    token_data: TokenData
    reasoning: List[str]
    timestamp: datetime = field(default_factory=datetime.now)
    message_id: Optional[int] = None

@dataclass
class TrackedToken:
    symbol: str
    status: TokenStatus
    first_seen: datetime
    last_update: datetime
    entry_price: Optional[float] = None
    current_price: Optional[float] = None
    message_id: Optional[int] = None
    pinned_message_id: Optional[int] = None
    highest_price: Optional[float] = None
    lowest_price: Optional[float] = None
    notes: List[str] = field(default_factory=list)
    
    def to_dict(self):
        return {
            'symbol': self.symbol,
            'status': self.status.value,
            'first_seen': self.first_seen.isoformat(),
            'last_update': self.last_update.isoformat(),
            'entry_price': self.entry_price,
            'current_price': self.current_price,
            'message_id': self.message_id,
            'highest_price': self.highest_price,
            'lowest_price': self.lowest_price,
            'notes': self.notes
        }

# ═══════════════════════════════════════════════════════════════════════════════
# BINANCE CLIENT
# ═══════════════════════════════════════════════════════════════════════════════

class BinanceClient:
    BASE_URL = "https://api.binance.com"
    
    def __init__(self):
        self.session = requests.Session()
        self.last_prices = {}
        self.request_count = 0
    
    def get_all_tickers(self) -> List[Dict]:
        try:
            response = self.session.get(f"{self.BASE_URL}/api/v3/ticker/24hr", timeout=10)
            self.request_count += 1
            return response.json()
        except Exception as e:
            logger.error(f"Error getting tickers: {e}")
            return []
    
    def get_klines(self, symbol: str, interval: str = "1h", limit: int = 100) -> List[List]:
        try:
            params = {"symbol": symbol, "interval": interval, "limit": limit}
            response = self.session.get(f"{self.BASE_URL}/api/v3/klines", params=params, timeout=10)
            self.request_count += 1
            return response.json()
        except Exception as e:
            logger.error(f"Error getting klines for {symbol}: {e}")
            return []
    
    def get_price(self, symbol: str) -> float:
        try:
            response = self.session.get(
                f"{self.BASE_URL}/api/v3/ticker/price", 
                params={"symbol": symbol},
                timeout=5
            )
            self.request_count += 1
            price = float(response.json().get("price", 0))
            self.last_prices[symbol] = price
            return price
        except Exception as e:
            return self.last_prices.get(symbol, 0)

# ═══════════════════════════════════════════════════════════════════════════════
# TECHNICAL ANALYZER
# ═══════════════════════════════════════════════════════════════════════════════

class TechnicalAnalyzer:
    def analyze(self, klines: List[List]) -> TechnicalIndicators:
        if not klines or len(klines) < 50:
            return TechnicalIndicators()
        
        df = pd.DataFrame(klines, columns=[
            'timestamp', 'open', 'high', 'low', 'close', 'volume',
            'close_time', 'quote_volume', 'trades', 'taker_buy_base',
            'taker_buy_quote', 'ignore'
        ])
        
        for col in ['open', 'high', 'low', 'close', 'volume']:
            df[col] = pd.to_numeric(df[col])
        
        prices = df['close']
        volumes = df['volume']
        
        ind = TechnicalIndicators()
        
        # RSI
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        ind.rsi = 100 - (100 / (1 + rs)).iloc[-1] if not pd.isna(rs.iloc[-1]) else 50
        
        # MACD
        exp1 = prices.ewm(span=12).mean()
        exp2 = prices.ewm(span=26).mean()
        ind.macd = (exp1 - exp2).iloc[-1]
        ind.macd_signal = (exp1 - exp2).ewm(span=9).mean().iloc[-1]
        
        # EMA
        ind.ema_20 = prices.ewm(span=20).mean().iloc[-1]
        ind.ema_50 = prices.ewm(span=50).mean().iloc[-1]
        ind.ema_200 = prices.ewm(span=200).mean().iloc[-1]
        
        # Trend
        if ind.ema_20 > ind.ema_50 > ind.ema_200:
            ind.trend = "STRONG_UPTREND"
        elif ind.ema_20 > ind.ema_50:
            ind.trend = "UPTREND"
        elif ind.ema_20 < ind.ema_50 < ind.ema_200:
            ind.trend = "STRONG_DOWNTREND"
        elif ind.ema_20 < ind.ema_50:
            ind.trend = "DOWNTREND"
        else:
            ind.trend = "SIDEWAYS"
        
        # Volume
        avg_volume = volumes.rolling(window=20).mean().iloc[-1]
        ind.volume_ratio = volumes.iloc[-1] / avg_volume if avg_volume > 0 else 1
        
        # Support/Resistance
        ind.support = prices.rolling(window=20).min().iloc[-1]
        ind.resistance = prices.rolling(window=20).max().iloc[-1]
        
        return ind

# ═══════════════════════════════════════════════════════════════════════════════
# SIGNAL ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class SignalEngine:
    def __init__(self):
        self.analyzer = TechnicalAnalyzer()
    
    def generate_signal(self, symbol: str, klines: List[List], token_data: TokenData) -> Optional[TradingSignal]:
        if not klines or len(klines) < 50:
            return None
        
        ind = self.analyzer.analyze(klines)
        current_price = float(klines[-1][4])
        
        score = 0
        confidence = 50
        reasons = []
        
        # RSI analysis
        if ind.rsi < 30:
            score += 3
            confidence += 15
            reasons.append(f"RSI перепродан ({ind.rsi:.1f})")
        elif ind.rsi < 40:
            score += 1
            confidence += 5
        elif ind.rsi > 70:
            score -= 2
            confidence -= 10
        
        # MACD
        if ind.macd > ind.macd_signal:
            score += 2
            confidence += 10
            reasons.append("MACD бычий кросс")
        elif ind.macd < ind.macd_signal:
            score -= 2
            confidence -= 10
        
        # Trend
        if ind.trend == "STRONG_UPTREND":
            score += 2
            confidence += 10
            reasons.append("Сильный восходящий тренд")
        elif ind.trend == "UPTREND":
            score += 1
            confidence += 5
        
        # Volume
        if ind.volume_ratio > 2:
            score += 1
            confidence += 5
            reasons.append(f"Высокий объем (x{ind.volume_ratio:.1f})")
        
        # Determine signal type
        if score >= 4 and confidence >= Config.MIN_CONFIDENCE:
            signal_type = SignalType.STRONG_BUY
        elif score >= 2 and confidence >= Config.MIN_CONFIDENCE - 10:
            signal_type = SignalType.BUY
        elif score <= -3:
            signal_type = SignalType.SELL
        else:
            signal_type = SignalType.WATCH
        
        # Calculate levels
        stop_loss = current_price * (1 - Config.STOP_LOSS / 100)
        targets = [
            current_price * (1 + Config.TAKE_PROFIT_1 / 100),
            current_price * (1 + Config.TAKE_PROFIT_2 / 100),
            current_price * (1 + Config.TAKE_PROFIT_3 / 100)
        ]
        
        return TradingSignal(
            symbol=symbol,
            signal_type=signal_type,
            entry_price=current_price,
            target_prices=targets,
            stop_loss=stop_loss,
            confidence=min(confidence, 95),
            indicators=ind,
            token_data=token_data,
            reasoning=reasons
        )

# ═══════════════════════════════════════════════════════════════════════════════
# TOKEN TRACKER - Управление состоянием токенов
# ═══════════════════════════════════════════════════════════════════════════════

class TokenTracker:
    def __init__(self):
        self.tokens: Dict[str, TrackedToken] = {}
        self.load_state()
    
    def load_state(self):
        try:
            with open('token_state.json', 'r', encoding='utf-8') as f:
                data = json.load(f)
                for symbol, token_data in data.items():
                    self.tokens[symbol] = TrackedToken(
                        symbol=token_data['symbol'],
                        status=TokenStatus(token_data['status']),
                        first_seen=datetime.fromisoformat(token_data['first_seen']),
                        last_update=datetime.fromisoformat(token_data['last_update']),
                        entry_price=token_data.get('entry_price'),
                        current_price=token_data.get('current_price'),
                        message_id=token_data.get('message_id'),
                        highest_price=token_data.get('highest_price'),
                        lowest_price=token_data.get('lowest_price'),
                        notes=token_data.get('notes', [])
                    )
        except FileNotFoundError:
            pass
    
    def save_state(self):
        data = {symbol: token.to_dict() for symbol, token in self.tokens.items()}
        with open('token_state.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    def should_show(self, symbol: str) -> bool:
        if symbol not in self.tokens:
            return True
        
        token = self.tokens[symbol]
        
        # Если игнорируем - проверяем срок
        if token.status == TokenStatus.IGNORED:
            hours_ignored = (datetime.now() - token.last_update).total_seconds() / 3600
            if hours_ignored >= Config.IGNORE_DURATION_HOURS:
                del self.tokens[symbol]
                self.save_state()
                return True
            return False
        
        # Если купили или продаем - показываем обновления
        if token.status in [TokenStatus.BOUGHT, TokenStatus.WATCHING]:
            return True
        
        # Если продали - не показываем
        if token.status == TokenStatus.SOLD:
            return False
        
        return True
    
    def add_token(self, symbol: str, status: TokenStatus, message_id: int = None, entry_price: float = None):
        now = datetime.now()
        
        if symbol in self.tokens:
            self.tokens[symbol].status = status
            self.tokens[symbol].last_update = now
            if message_id:
                self.tokens[symbol].message_id = message_id
            if entry_price:
                self.tokens[symbol].entry_price = entry_price
                self.tokens[symbol].highest_price = entry_price
                self.tokens[symbol].lowest_price = entry_price
        else:
            self.tokens[symbol] = TrackedToken(
                symbol=symbol,
                status=status,
                first_seen=now,
                last_update=now,
                message_id=message_id,
                entry_price=entry_price,
                current_price=entry_price,
                highest_price=entry_price,
                lowest_price=entry_price
            )
        
        self.save_state()
    
    def update_price(self, symbol: str, price: float):
        if symbol in self.tokens:
            self.tokens[symbol].current_price = price
            self.tokens[symbol].last_update = datetime.now()
            
            if self.tokens[symbol].highest_price is None or price > self.tokens[symbol].highest_price:
                self.tokens[symbol].highest_price = price
            if self.tokens[symbol].lowest_price is None or price < self.tokens[symbol].lowest_price:
                self.tokens[symbol].lowest_price = price
            
            self.save_state()
    
    def set_pinned_message(self, symbol: str, pinned_id: int):
        if symbol in self.tokens:
            self.tokens[symbol].pinned_message_id = pinned_id
            self.save_state()
    
    def add_note(self, symbol: str, note: str):
        if symbol in self.tokens:
            self.tokens[symbol].notes.append(f"{datetime.now().strftime('%H:%M')} - {note}")
            self.save_state()
    
    def get_active_tokens(self) -> List[TrackedToken]:
        return [t for t in self.tokens.values() if t.status in [TokenStatus.WATCHING, TokenStatus.BOUGHT]]

# ═══════════════════════════════════════════════════════════════════════════════
# TELEGRAM BOT HANDLER
# ═══════════════════════════════════════════════════════════════════════════════

class TelegramHandler:
    def __init__(self, bot_instance: 'ProTraderBot'):
        self.bot = bot_instance
        self.application = None
        self.message_queue = asyncio.Queue()
        self.running = False
    
    async def setup(self):
        self.application = Application.builder().token(Config.TG_TOKEN).build()
        
        # Command handlers
        self.application.add_handler(CommandHandler("start", self.cmd_start))
        self.application.add_handler(CommandHandler("portfolio", self.cmd_portfolio))
        self.application.add_handler(CommandHandler("watching", self.cmd_watching))
        self.application.add_handler(CommandHandler("active", self.cmd_active))
        self.application.add_handler(CommandHandler("stats", self.cmd_stats))
        self.application.add_handler(CommandHandler("reset", self.cmd_reset))
        
        # Callback handlers for buttons
        self.application.add_handler(CallbackQueryHandler(self.on_callback, pattern="^"))
        
        # Start
        await self.application.initialize()
        await self.application.start()
        asyncio.create_task(self.application.updater.start_polling())
        
        self.running = True
        asyncio.create_task(self._process_queue())
    
    async def _process_queue(self):
        while self.running:
            try:
                task = await asyncio.wait_for(self.message_queue.get(), timeout=1)
                await task()
                await asyncio.sleep(0.5)  # Rate limiting
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Queue error: {e}")
    
    def get_signal_keyboard(self, symbol: str) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("💚 ПОКУПАЮ", callback_data=f"buy:{symbol}"),
                InlineKeyboardButton("👁 МОНИТОРЮ", callback_data=f"watch:{symbol}")
            ],
            [
                InlineKeyboardButton("❌ Неинтересно", callback_data=f"ignore:{symbol}")
            ]
        ])
    
    def get_bought_keyboard(self, symbol: str) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("💰 Фикс прибыли 50%", callback_data=f"tp50:{symbol}"),
                InlineKeyboardButton("💰 Фикс 100%", callback_data=f"tp100:{symbol}")
            ],
            [
                InlineKeyboardButton("🛑 Стоп-лосс", callback_data=f"stop:{symbol}"),
                InlineKeyboardButton("📊 Обновить", callback_data=f"update:{symbol}")
            ],
            [
                InlineKeyboardButton("✅ Продано", callback_data=f"sold:{symbol}")
            ]
        ])
    
    def get_watching_keyboard(self, symbol: str) -> InlineKeyboardMarkup:
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("💚 КУПИТЬ", callback_data=f"buy:{symbol}"),
                InlineKeyboardButton("❌ Забыть", callback_data=f"ignore:{symbol}")
            ],
            [
                InlineKeyboardButton("📊 Обновить цену", callback_data=f"update:{symbol}")
            ]
        ])
    
    async def send_signal(self, signal: TradingSignal) -> int:
        emoji = {"STRONG_BUY": "🚀", "BUY": "💚", "SELL": "🔴", "WATCH": "👁"}.get(signal.signal_type.value, "📊")
        
        message = f"""{emoji} <b>{signal.signal_type.value} - {signal.symbol}</b>

💰 <b>Цена:</b> <code>${signal.entry_price:.6f}</code>
📊 <b>Уверенность:</b> {signal.confidence}%
📈 <b>24ч:</b> {signal.token_data.price_change_24h:+.2f}%

🎯 <b>Цели:</b>
   TP1: ${signal.target_prices[0]:.6f} (+{((signal.target_prices[0]/signal.entry_price-1)*100):.1f}%)
   TP2: ${signal.target_prices[1]:.6f} (+{((signal.target_prices[1]/signal.entry_price-1)*100):.1f}%)
   TP3: ${signal.target_prices[2]:.6f} (+{((signal.target_prices[2]/signal.entry_price-1)*100):.1f}%)

🛑 <b>Стоп:</b> ${signal.stop_loss:.6f} ({((signal.stop_loss/signal.entry_price-1)*100):.1f}%)

📉 <b>RSI:</b> {signal.indicators.rsi:.1f} | <b>Trend:</b> {signal.indicators.trend}
📊 <b>Volume:</b> x{signal.indicators.volume_ratio:.1f}

💡 <b>Почему:</b>
"""
        for reason in signal.reasoning[:3]:
            message += f"   • {reason}\n"
        
        async def send():
            try:
                msg = await self.application.bot.send_message(
                    chat_id=Config.CHAT_ID,
                    text=message,
                    parse_mode=ParseMode.HTML,
                    reply_markup=self.get_signal_keyboard(signal.symbol)
                )
                return msg.message_id
            except Exception as e:
                logger.error(f"Error sending signal: {e}")
                return None
        
        future = asyncio.Future()
        async def task():
            result = await send()
            future.set_result(result)
        
        await self.message_queue.put(task)
        return await future
    
    async def update_message(self, symbol: str, message_id: int, text: str, keyboard=None):
        async def update():
            try:
                await self.application.bot.edit_message_text(
                    text=text,
                    chat_id=Config.CHAT_ID,
                    message_id=message_id,
                    parse_mode=ParseMode.HTML,
                    reply_markup=keyboard
                )
            except Exception as e:
                logger.error(f"Error updating message: {e}")
        
        await self.message_queue.put(update)
    
    async def pin_message(self, message_id: int):
        async def pin():
            try:
                await self.application.bot.pin_chat_message(
                    chat_id=Config.CHAT_ID,
                    message_id=message_id
                )
            except Exception as e:
                logger.error(f"Error pinning message: {e}")
        
        await self.message_queue.put(pin)
    
    async def send_alert(self, text: str):
        async def send():
            try:
                await self.application.bot.send_message(
                    chat_id=Config.CHAT_ID,
                    text=text,
                    parse_mode=ParseMode.HTML
                )
            except Exception as e:
                logger.error(f"Error sending alert: {e}")
        
        await self.message_queue.put(send)
    
    # Command handlers
    async def cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text(
            "<b>🚀 Pro Trader Bot</b>\n\n"
            "Команды:\n"
            "/portfolio - Портфель\n"
            "/watching - Мониторинг\n"
            "/active - Активные сделки\n"
            "/stats - Статистика\n"
            "/reset - Сброс состояния",
            parse_mode=ParseMode.HTML
        )
    
    async def cmd_portfolio(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        active = self.bot.tracker.get_active_tokens()
        
        if not active:
            await update.message.reply_text("📭 Портфель пуст")
            return
        
        total_pnl = 0
        message = "<b>💼 ПОРТФЕЛЬ</b>\n\n"
        
        for token in active:
            if token.entry_price and token.current_price:
                pnl = (token.current_price / token.entry_price - 1) * 100
                total_pnl += pnl
                emoji = "🟢" if pnl > 0 else "🔴"
                message += f"{emoji} <b>{token.symbol}</b>: {pnl:+.2f}%\n"
        
        message += f"\n<b>Общий P&L:</b> {total_pnl:+.2f}%"
        await update.message.reply_text(message, parse_mode=ParseMode.HTML)
    
    async def cmd_watching(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        watching = [t for t in self.bot.tracker.tokens.values() if t.status == TokenStatus.WATCHING]
        
        if not watching:
            await update.message.reply_text("👁 Нет токенов на мониторинге")
            return
        
        message = "<b>👁 НА МОНИТОРИНГЕ</b>\n\n"
        for token in watching:
            message += f"• {token.symbol} - ${token.current_price:.6f}\n"
        
        await update.message.reply_text(message, parse_mode=ParseMode.HTML)
    
    async def cmd_active(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        bought = [t for t in self.bot.tracker.tokens.values() if t.status == TokenStatus.BOUGHT]
        
        if not bought:
            await update.message.reply_text("💚 Нет активных покупок")
            return
        
        message = "<b>💚 АКТИВНЫЕ ПОКУПКИ</b>\n\n"
        for token in bought:
            if token.entry_price and token.current_price:
                pnl = (token.current_price / token.entry_price - 1) * 100
                emoji = "🟢" if pnl > 0 else "🔴"
                message += f"{emoji} <b>{token.symbol}</b>\n"
                message += f"   Вход: ${token.entry_price:.6f}\n"
                message += f"   Сейчас: ${token.current_price:.6f}\n"
                message += f"   P&L: {pnl:+.2f}%\n\n"
        
        await update.message.reply_text(message, parse_mode=ParseMode.HTML)
    
    async def cmd_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        all_tokens = self.bot.tracker.tokens
        
        stats = {
            'new': len([t for t in all_tokens.values() if t.status == TokenStatus.NEW]),
            'watching': len([t for t in all_tokens.values() if t.status == TokenStatus.WATCHING]),
            'bought': len([t for t in all_tokens.values() if t.status == TokenStatus.BOUGHT]),
            'ignored': len([t for t in all_tokens.values() if t.status == TokenStatus.IGNORED]),
            'sold': len([t for t in all_tokens.values() if t.status == TokenStatus.SOLD]),
        }
        
        message = f"""<b>📊 СТАТИСТИКА</b>

Всего токенов: {len(all_tokens)}
• Новых: {stats['new']}
• На мониторинге: {stats['watching']}
• Куплено: {stats['bought']}
• Игнор: {stats['ignored']}
• Продано: {stats['sold']}

Сканировано: {self.bot.scanned_count}
Сигналов: {self.bot.signals_sent}
"""
        await update.message.reply_text(message, parse_mode=ParseMode.HTML)
    
    async def cmd_reset(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        self.bot.tracker.tokens = {}
        self.bot.tracker.save_state()
        await update.message.reply_text("✅ Состояние сброшено")
    
    # Callback handlers
    async def on_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        
        data = query.data
        action, symbol = data.split(":", 1)
        
        if action == "buy":
            await self.handle_buy(symbol, query)
        elif action == "watch":
            await self.handle_watch(symbol, query)
        elif action == "ignore":
            await self.handle_ignore(symbol, query)
        elif action == "update":
            await self.handle_update(symbol, query)
        elif action == "stop":
            await self.handle_stop(symbol, query)
        elif action == "sold":
            await self.handle_sold(symbol, query)
        elif action == "tp50":
            await self.handle_tp(symbol, query, 50)
        elif action == "tp100":
            await self.handle_tp(symbol, query, 100)
    
    async def handle_buy(self, symbol: str, query):
        price = self.bot.binance.get_price(symbol)
        
        # Update tracker
        self.bot.tracker.add_token(symbol, TokenStatus.BOUGHT, query.message.message_id, price)
        self.bot.tracker.add_note(symbol, f"Куплено по ${price:.6f}")
        
        # Calculate levels
        sl = price * (1 - Config.STOP_LOSS / 100)
        tp1 = price * (1 + Config.TAKE_PROFIT_1 / 100)
        tp2 = price * (1 + Config.TAKE_PROFIT_2 / 100)
        tp3 = price * (1 + Config.TAKE_PROFIT_3 / 100)
        
        new_text = f"""💚 <b>В ПОЗИЦИИ - {symbol}</b>

💰 <b>Вход:</b> <code>${price:.6f}</code>
📊 <b>Статус:</b> Активна

🎯 <b>Цели:</b>
   TP1: ${tp1:.6f} (+{Config.TAKE_PROFIT_1}%)
   TP2: ${tp2:.6f} (+{Config.TAKE_PROFIT_2}%)
   TP3: ${tp3:.6f} (+{Config.TAKE_PROFIT_3}%)

🛑 <b>Стоп:</b> ${sl:.6f} (-{Config.STOP_LOSS}%)

⏰ <b>Время входа:</b> {datetime.now().strftime('%H:%M:%S')}

<i>Бот будет отслеживать и обновлять цену каждые 5 минут</i>
"""
        
        await query.edit_message_text(
            text=new_text,
            parse_mode=ParseMode.HTML,
            reply_markup=self.get_bought_keyboard(symbol)
        )
        
        # Pin the message
        await self.pin_message(query.message.message_id)
        self.bot.tracker.set_pinned_message(symbol, query.message.message_id)
        
        await self.send_alert(f"✅ <b>{symbol}</b> добавлен в портфель по ${price:.6f}")
    
    async def handle_watch(self, symbol: str, query):
        price = self.bot.binance.get_price(symbol)
        
        self.bot.tracker.add_token(symbol, TokenStatus.WATCHING, query.message.message_id, price)
        self.bot.tracker.add_note(symbol, f"Начат мониторинг с ${price:.6f}")
        
        new_text = f"""👁 <b>НА МОНИТОРИНГЕ - {symbol}</b>

💰 <b>Текущая цена:</b> <code>${price:.6f}</code>
📊 <b>Статус:</b> Ожидание точки входа

💡 <b>Рекомендации:</b>
   • Ждите отката к поддержке
   • Следите за объемами
   • Входите частями

<i>Бот отследит лучший момент для входа</i>
"""
        
        await query.edit_message_text(
            text=new_text,
            parse_mode=ParseMode.HTML,
            reply_markup=self.get_watching_keyboard(symbol)
        )
        
        await self.send_alert(f"👁 Начат мониторинг <b>{symbol}</b> по ${price:.6f}")
    
    async def handle_ignore(self, symbol: str, query):
        self.bot.tracker.add_token(symbol, TokenStatus.IGNORED, query.message.message_id)
        
        await query.edit_message_text(
            text=f"❌ <b>{symbol}</b> - Пропущено\n\n<i>Не будем показывать 24 часа</i>",
            parse_mode=ParseMode.HTML
        )
    
    async def handle_update(self, symbol: str, query):
        price = self.bot.binance.get_price(symbol)
        token = self.bot.tracker.tokens.get(symbol)
        
        if not token:
            return
        
        self.bot.tracker.update_price(symbol, price)
        
        if token.status == TokenStatus.BOUGHT and token.entry_price:
            pnl = (price / token.entry_price - 1) * 100
            
            # Determine recommendation
            if pnl >= Config.TAKE_PROFIT_3:
                rec = "🎯 <b>ЦЕЛЬ 3 ДОСТИГНУТА!</b>\n   Рекомендация: Закрыть 100% позиции"
            elif pnl >= Config.TAKE_PROFIT_2:
                rec = f"🎯 <b>ЦЕЛЬ 2 ДОСТИГНУТА!</b>\n   Рекомендация: Закрыть 50% позиции"
            elif pnl >= Config.TAKE_PROFIT_1:
                rec = f"🎯 <b>ЦЕЛЬ 1 ДОСТИГНУТА!</b>\n   Рекомендация: Закрыть 30% позиции"
            elif pnl <= -Config.STOP_LOSS:
                rec = f"🛑 <b>СТОП-ЛОСС!</b>\n   Рекомендация: Закрыть позицию"
            elif pnl > 0:
                rec = f"📈 <b>В ПРИБЫЛИ</b>\n   Рекомендация: Держать, двигайте стоп в безубыток"
            else:
                rec = f"📉 <b>В УБЫТКЕ</b>\n   Рекомендация: Держать, ждать разворота"
            
            new_text = f"""💚 <b>В ПОЗИЦИИ - {symbol}</b>

💰 <b>Вход:</b> <code>${token.entry_price:.6f}</code>
💰 <b>Сейчас:</b> <code>${price:.6f}</code>
📊 <b>P&L:</b> <code>{pnl:+.2f}%</code>

{rec}

📈 <b>Статистика:</b>
   Макс: ${token.highest_price:.6f}
   Мин: ${token.lowest_price:.6f}

⏰ <b>Обновлено:</b> {datetime.now().strftime('%H:%M:%S')}
"""
            
            await query.edit_message_text(
                text=new_text,
                parse_mode=ParseMode.HTML,
                reply_markup=self.get_bought_keyboard(symbol)
            )
        
        elif token.status == TokenStatus.WATCHING:
            new_text = f"""👁 <b>НА МОНИТОРИНГЕ - {symbol}</b>

💰 <b>Текущая цена:</b> <code>${price:.6f}</code>

💡 <b>Анализ:</b>
   • Следите за пробоем уровней
   • Ждите подтверждения объемом
   • Входите частями (DCA)

⏰ <b>Обновлено:</b> {datetime.now().strftime('%H:%M:%S')}
"""
            
            await query.edit_message_text(
                text=new_text,
                parse_mode=ParseMode.HTML,
                reply_markup=self.get_watching_keyboard(symbol)
            )
    
    async def handle_stop(self, symbol: str, query):
        await query.edit_message_text(
            text=f"🛑 <b>СТОП-ЛОСС - {symbol}</b>\n\n<i>Позиция закрыта по стопу</i>",
            parse_mode=ParseMode.HTML
        )
        self.bot.tracker.add_token(symbol, TokenStatus.SOLD)
        self.bot.tracker.add_note(symbol, "Закрыто по стоп-лоссу")
    
    async def handle_sold(self, symbol: str, query):
        token = self.bot.tracker.tokens.get(symbol)
        if token and token.entry_price and token.current_price:
            pnl = (token.current_price / token.entry_price - 1) * 100
            result = "прибылью" if pnl > 0 else "убытком"
            
            await query.edit_message_text(
                text=f"✅ <b>ПРОДАНО - {symbol}</b>\n\nP&L: {pnl:+.2f}%\nРезультат: С {result}",
                parse_mode=ParseMode.HTML
            )
            
            self.bot.tracker.add_token(symbol, TokenStatus.SOLD)
            self.bot.tracker.add_note(symbol, f"Продано с P&L {pnl:+.2f}%")
    
    async def handle_tp(self, symbol: str, query, percent: int):
        await query.answer(f"Зафиксировано {percent}% прибыли!")
        self.bot.tracker.add_note(symbol, f"Зафиксировано {percent}% прибыли")

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN BOT
# ═══════════════════════════════════════════════════════════════════════════════

class ProTraderBot:
    def __init__(self):
        self.binance = BinanceClient()
        self.signal_engine = SignalEngine()
        self.tracker = TokenTracker()
        self.telegram = TelegramHandler(self)
        
        self.running = False
        self.scanned_count = 0
        self.signals_sent = 0
        self.start_time = None
    
    async def start(self):
        self.running = True
        self.start_time = datetime.now()
        
        logger.info("=" * 60)
        logger.info("PRO TRADER BOT ЗАПУЩЕН!")
        logger.info("=" * 60)
        
        # Setup Telegram
        await self.telegram.setup()
        await self.telegram.send_alert("<b>🚀 Бот запущен!</b>\n\nНачинаю сканирование рынка...")
        
        # Start main loops
        await asyncio.gather(
            self._scanning_loop(),
            self._price_update_loop(),
            self._monitoring_loop()
        )
    
    async def _scanning_loop(self):
        """Main scanning loop - finds new opportunities"""
        while self.running:
            try:
                logger.info("[SCAN] Сканирование рынка...")
                
                tickers = self.binance.get_all_tickers()
                
                # Filter USDT pairs with volume
                usdt_pairs = [
                    t for t in tickers 
                    if t.get('symbol', '').endswith('USDT') and
                    float(t.get('quoteVolume', 0)) > Config.MIN_VOLUME_24H
                ]
                
                # Sort by volume
                usdt_pairs.sort(key=lambda x: float(x.get('quoteVolume', 0)), reverse=True)
                
                # Take top 50
                top_pairs = usdt_pairs[:50]
                
                signals_this_scan = 0
                
                for ticker in top_pairs:
                    if not self.running:
                        break
                    
                    symbol = ticker['symbol']
                    
                    # Check if we should show this token
                    if not self.tracker.should_show(symbol):
                        continue
                    
                    # Skip if already watching or bought
                    if symbol in self.tracker.tokens:
                        token = self.tracker.tokens[symbol]
                        if token.status in [TokenStatus.WATCHING, TokenStatus.BOUGHT]:
                            continue
                    
                    try:
                        klines = self.binance.get_klines(symbol, '1h', 100)
                        
                        if not klines or len(klines) < 50:
                            continue
                        
                        token_data = TokenData(
                            symbol=symbol,
                            name=symbol.replace('USDT', ''),
                            price=float(ticker.get('lastPrice', 0)),
                            price_change_24h=float(ticker.get('priceChangePercent', 0)),
                            volume_24h=float(ticker.get('quoteVolume', 0)),
                        )
                        
                        signal = self.signal_engine.generate_signal(symbol, klines, token_data)
                        
                        if signal and signal.signal_type in [SignalType.STRONG_BUY, SignalType.BUY]:
                            # Send signal with buttons
                            message_id = await self.telegram.send_signal(signal)
                            
                            if message_id:
                                self.tracker.add_token(symbol, TokenStatus.NEW, message_id, signal.entry_price)
                                self.signals_sent += 1
                                signals_this_scan += 1
                                
                                logger.info(f"[SIGNAL] {symbol} - {signal.signal_type.value} ({signal.confidence}%)")
                        
                        self.scanned_count += 1
                        await asyncio.sleep(0.1)
                        
                    except Exception as e:
                        logger.error(f"[ERROR] Анализ {symbol}: {e}")
                        continue
                
                logger.info(f"[SCAN] Завершено. Просканировано: {self.scanned_count}, Сигналов: {self.signals_sent}")
                
                await asyncio.sleep(Config.SCAN_INTERVAL)
                
            except Exception as e:
                logger.error(f"[ERROR] Scanning loop: {e}")
                await asyncio.sleep(10)
    
    async def _price_update_loop(self):
        """Updates prices for active tokens"""
        while self.running:
            try:
                active_tokens = self.tracker.get_active_tokens()
                
                for token in active_tokens:
                    price = self.binance.get_price(token.symbol)
                    if price > 0:
                        self.tracker.update_price(token.symbol, price)
                        
                        # Check for significant price movements
                        if token.entry_price:
                            pnl = (price / token.entry_price - 1) * 100
                            
                            # Alert on TP/SL
                            if pnl >= Config.TAKE_PROFIT_1 and 'tp1_alerted' not in token.notes:
                                await self.telegram.send_alert(
                                    f"🎯 <b>{token.symbol}</b> достигла TP1!\n"
                                    f"P&L: +{pnl:.2f}%"
                                )
                                self.tracker.add_note(token.symbol, 'tp1_alerted')
                            
                            elif pnl <= -Config.STOP_LOSS and 'sl_alerted' not in token.notes:
                                await self.telegram.send_alert(
                                    f"🛑 <b>{token.symbol}</b> достигла стоп-лосса!\n"
                                    f"P&L: {pnl:.2f}%"
                                )
                                self.tracker.add_note(token.symbol, 'sl_alerted')
                
                await asyncio.sleep(Config.WATCH_UPDATE_INTERVAL)
                
            except Exception as e:
                logger.error(f"[ERROR] Price update loop: {e}")
                await asyncio.sleep(10)
    
    async def _monitoring_loop(self):
        """Monitors watching tokens for entry opportunities"""
        while self.running:
            try:
                watching = [t for t in self.tracker.tokens.values() if t.status == TokenStatus.WATCHING]
                
                for token in watching:
                    # Get fresh data
                    klines = self.binance.get_klines(token.symbol, '1h', 50)
                    
                    if klines:
                        ind = self.signal_engine.analyzer.analyze(klines)
                        
                        # Check for good entry opportunity
                        if ind.rsi < 35 and ind.macd > ind.macd_signal:
                            await self.telegram.send_alert(
                                f"💡 <b>{token.symbol}</b> - Хорошая точка входа!\n"
                                f"RSI: {ind.rsi:.1f} (перепродан)\n"
                                f"MACD: Бычий кросс\n"
                                f"Цена: ${token.current_price:.6f}"
                            )
                
                await asyncio.sleep(600)  # Check every 10 minutes
                
            except Exception as e:
                logger.error(f"[ERROR] Monitoring loop: {e}")
                await asyncio.sleep(10)
    
    def stop(self):
        self.running = False
        logger.info("[STOP] Бот остановлен")

# ═══════════════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    print("""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    🚀 PRO TRADER BOT - ULTIMATE EDITION 🚀                    ║
║                                                                               ║
║  Функции:                                                                     ║
║  • 💚 Покупаю / 👁 Мониторю / ❌ Неинтересно                                  ║
║  • Обновление сообщений в реальном времени                                    ║
║  • Закрепление активных сделок                                                ║
║  • Умная фильтрация токенов                                                   ║
║  • Вечный мониторинг                                                          ║
╚═══════════════════════════════════════════════════════════════════════════════╝
""")
    
    bot = ProTraderBot()
    
    try:
        asyncio.run(bot.start())
    except KeyboardInterrupt:
        print("\n\n🛑 Остановка...")
        bot.stop()
    except Exception as e:
        print(f"\n❌ Ошибка: {e}")
        bot.stop()

if __name__ == "__main__":
    main()
