#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                         🧠 AI ANALYZER MODULE 🧠                              ║
║                                                                               ║
║  AI-подобный анализатор для предсказания движения цен                        ║
║  • Паттерн-рекогниция                                                        ║
║  • Сентимент-анализ                                                          ║
║  • Предсказание направления                                                  ║
║  • Оценка вероятности успеха сделки                                          ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
from collections import deque
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class PatternType(Enum):
    DOUBLE_BOTTOM = "Двойное дно"
    DOUBLE_TOP = "Двойная вершина"
    HEAD_SHOULDERS = "Голова и плечи"
    INV_HEAD_SHOULDERS = "Перевернутая голова и плечи"
    TRIANGLE_ASCENDING = "Восходящий треугольник"
    TRIANGLE_DESCENDING = "Нисходящий треугольник"
    FLAG_BULL = "Бычий флаг"
    FLAG_BEAR = "Медвежий флаг"
    CUP_HANDLE = "Чашка с ручкой"
    WEDGE_FALLING = "Падающий клин"
    WEDGE_RISING = "Растущий клин"

@dataclass
class Pattern:
    """Торговый паттерн"""
    pattern_type: PatternType
    confidence: float  # 0-100
    start_idx: int
    end_idx: int
    target_price: float
    stop_loss: float
    description: str

@dataclass
class SentimentScore:
    """Оценка настроения"""
    overall: float  # -100 до 100
    technical: float
    volume: float
    momentum: float
    trend_strength: float

@dataclass
class Prediction:
    """Предсказание движения"""
    direction: str  # UP, DOWN, SIDEWAYS
    confidence: float
    target_price: float
    timeframe: str
    probability_up: float
    probability_down: float
    probability_sideways: float
    key_levels: Dict[str, float]
    reasoning: List[str]

class PatternRecognizer:
    """Распознаватель паттернов"""
    
    def __init__(self):
        self.min_pattern_length = 10
        self.max_pattern_length = 50
    
    def find_patterns(self, df: pd.DataFrame) -> List[Pattern]:
        """Найти все паттерны в данных"""
        patterns = []
        
        # Двойное дно
        db = self._find_double_bottom(df)
        if db:
            patterns.append(db)
        
        # Двойная вершина
        dt = self._find_double_top(df)
        if dt:
            patterns.append(dt)
        
        # Голова и плечи
        hs = self._find_head_shoulders(df)
        if hs:
            patterns.append(hs)
        
        # Треугольники
        tri = self._find_triangles(df)
        patterns.extend(tri)
        
        # Флаги
        flags = self._find_flags(df)
        patterns.extend(flags)
        
        return patterns
    
    def _find_double_bottom(self, df: pd.DataFrame) -> Optional[Pattern]:
        """Найти паттерн двойное дно"""
        if len(df) < 20:
            return None
        
        lows = df['low'].values
        
        # Ищем два минимума с примерно одинаковым уровнем
        for i in range(10, len(lows) - 5):
            first_bottom = lows[i-10:i].min()
            first_bottom_idx = i-10 + lows[i-10:i].argmin()
            
            second_bottom = lows[i:i+5].min()
            second_bottom_idx = i + lows[i:i+5].argmin()
            
            # Проверяем, что дна примерно на одном уровне (в пределах 3%)
            if abs(first_bottom - second_bottom) / first_bottom < 0.03:
                # Проверяем, что есть подъем между днами
                middle_high = lows[first_bottom_idx:second_bottom_idx].max()
                
                if middle_high > first_bottom * 1.02:
                    # Рассчитываем цель
                    neckline = middle_high
                    target = neckline + (neckline - first_bottom)
                    
                    return Pattern(
                        pattern_type=PatternType.DOUBLE_BOTTOM,
                        confidence=75,
                        start_idx=first_bottom_idx,
                        end_idx=second_bottom_idx,
                        target_price=target,
                        stop_loss=first_bottom * 0.98,
                        description=f"Двойное дно на уровне ${first_bottom:.4f}"
                    )
        
        return None
    
    def _find_double_top(self, df: pd.DataFrame) -> Optional[Pattern]:
        """Найти паттерн двойная вершина"""
        if len(df) < 20:
            return None
        
        highs = df['high'].values
        
        for i in range(10, len(highs) - 5):
            first_top = highs[i-10:i].max()
            first_top_idx = i-10 + highs[i-10:i].argmax()
            
            second_top = highs[i:i+5].max()
            second_top_idx = i + highs[i:i+5].argmax()
            
            if abs(first_top - second_top) / first_top < 0.03:
                middle_low = highs[first_top_idx:second_top_idx].min()
                
                if middle_low < first_top * 0.98:
                    neckline = middle_low
                    target = neckline - (first_top - neckline)
                    
                    return Pattern(
                        pattern_type=PatternType.DOUBLE_TOP,
                        confidence=75,
                        start_idx=first_top_idx,
                        end_idx=second_top_idx,
                        target_price=target,
                        stop_loss=first_top * 1.02,
                        description=f"Двойная вершина на уровне ${first_top:.4f}"
                    )
        
        return None
    
    def _find_head_shoulders(self, df: pd.DataFrame) -> Optional[Pattern]:
        """Найти паттерн голова и плечи"""
        if len(df) < 30:
            return None
        
        highs = df['high'].values
        
        # Упрощенная реализация
        # Ищем три пика, где средний выше боковых
        for i in range(15, len(highs) - 15):
            left_shoulder = highs[i-15:i-5].max()
            head = highs[i-5:i+5].max()
            right_shoulder = highs[i+5:i+15].max()
            
            # Голова выше плеч
            if head > left_shoulder and head > right_shoulder:
                # Плечи примерно на одном уровне
                if abs(left_shoulder - right_shoulder) / left_shoulder < 0.05:
                    neckline = min(highs[i-15:i+15].min(), left_shoulder * 0.95)
                    target = neckline - (head - neckline)
                    
                    return Pattern(
                        pattern_type=PatternType.HEAD_SHOULDERS,
                        confidence=70,
                        start_idx=i-15,
                        end_idx=i+15,
                        target_price=target,
                        stop_loss=head * 1.02,
                        description=f"Голова и плечи, голова на ${head:.4f}"
                    )
        
        return None
    
    def _find_triangles(self, df: pd.DataFrame) -> List[Pattern]:
        """Найти треугольники"""
        patterns = []
        
        if len(df) < 20:
            return patterns
        
        highs = df['high'].values[-20:]
        lows = df['low'].values[-20:]
        
        # Восходящий треугольник (плоское сопротивление, восходящая поддержка)
        high_trend = np.polyfit(range(len(highs)), highs, 1)[0]
        low_trend = np.polyfit(range(len(lows)), lows, 1)[0]
        
        if abs(high_trend) / highs.mean() < 0.001 and low_trend > 0:
            patterns.append(Pattern(
                pattern_type=PatternType.TRIANGLE_ASCENDING,
                confidence=65,
                start_idx=len(df)-20,
                end_idx=len(df)-1,
                target_price=highs[-1] + (highs[-1] - lows[0]),
                stop_loss=lows[-1] * 0.98,
                description="Восходящий треугольник"
            ))
        
        # Нисходящий треугольник
        if abs(low_trend) / lows.mean() < 0.001 and high_trend < 0:
            patterns.append(Pattern(
                pattern_type=PatternType.TRIANGLE_DESCENDING,
                confidence=65,
                start_idx=len(df)-20,
                end_idx=len(df)-1,
                target_price=lows[-1] - (highs[0] - lows[-1]),
                stop_loss=highs[-1] * 1.02,
                description="Нисходящий треугольник"
            ))
        
        return patterns
    
    def _find_flags(self, df: pd.DataFrame) -> List[Pattern]:
        """Найти флаги"""
        patterns = []
        
        if len(df) < 15:
            return patterns
        
        closes = df['close'].values
        
        # Проверяем сильное движение перед флагом
        price_change = (closes[-10] - closes[-15]) / closes[-15]
        
        if abs(price_change) > 0.05:  # 5% движение
            # Проверяем консолидацию (флаг)
            flag_range = closes[-10:]
            flag_volatility = np.std(flag_range) / np.mean(flag_range)
            
            if flag_volatility < 0.02:  # Низкая волатильность во флаге
                if price_change > 0:
                    patterns.append(Pattern(
                        pattern_type=PatternType.FLAG_BULL,
                        confidence=70,
                        start_idx=len(df)-15,
                        end_idx=len(df)-1,
                        target_price=closes[-1] + (closes[-10] - closes[-15]),
                        stop_loss=flag_range.min() * 0.99,
                        description="Бычий флаг после импульса"
                    ))
                else:
                    patterns.append(Pattern(
                        pattern_type=PatternType.FLAG_BEAR,
                        confidence=70,
                        start_idx=len(df)-15,
                        end_idx=len(df)-1,
                        target_price=closes[-1] - (closes[-15] - closes[-10]),
                        stop_loss=flag_range.max() * 1.01,
                        description="Медвежий флаг после импульса"
                    ))
        
        return patterns

class SentimentAnalyzer:
    """Анализатор настроения рынка"""
    
    def __init__(self):
        self.price_history = deque(maxlen=100)
        self.volume_history = deque(maxlen=100)
    
    def analyze(self, df: pd.DataFrame) -> SentimentScore:
        """Проанализировать настроение"""
        
        closes = df['close'].values
        volumes = df['volume'].values
        highs = df['high'].values
        lows = df['low'].values
        
        # Технический скор
        technical_score = self._calculate_technical_score(closes)
        
        # Скор объема
        volume_score = self._calculate_volume_score(volumes)
        
        # Моментум
        momentum_score = self._calculate_momentum(closes)
        
        # Сила тренда
        trend_strength = self._calculate_trend_strength(closes)
        
        # Общий скор
        overall = (technical_score + volume_score + momentum_score + trend_strength) / 4
        
        return SentimentScore(
            overall=overall,
            technical=technical_score,
            volume=volume_score,
            momentum=momentum_score,
            trend_strength=trend_strength
        )
    
    def _calculate_technical_score(self, closes: np.ndarray) -> float:
        """Рассчитать технический скор"""
        if len(closes) < 20:
            return 0
        
        # EMA позиция
        ema_20 = pd.Series(closes).ewm(span=20).mean().iloc[-1]
        current = closes[-1]
        
        score = 0
        
        if current > ema_20:
            score += 20
        else:
            score -= 20
        
        # Направление цены
        price_change_5 = (closes[-1] - closes[-5]) / closes[-5] * 100
        price_change_20 = (closes[-1] - closes[-20]) / closes[-20] * 100
        
        score += price_change_5 * 2
        score += price_change_20
        
        return max(-100, min(100, score))
    
    def _calculate_volume_score(self, volumes: np.ndarray) -> float:
        """Рассчитать скор объема"""
        if len(volumes) < 20:
            return 0
        
        avg_volume = np.mean(volumes[-20:])
        current_volume = volumes[-1]
        
        ratio = current_volume / avg_volume if avg_volume > 0 else 1
        
        if ratio > 3:
            return 50
        elif ratio > 2:
            return 30
        elif ratio > 1.5:
            return 15
        elif ratio > 1:
            return 5
        elif ratio > 0.5:
            return -10
        else:
            return -30
    
    def _calculate_momentum(self, closes: np.ndarray) -> float:
        """Рассчитать моментум"""
        if len(closes) < 14:
            return 0
        
        # Простой моментум
        momentum = (closes[-1] - closes[-14]) / closes[-14] * 100
        
        return max(-100, min(100, momentum * 3))
    
    def _calculate_trend_strength(self, closes: np.ndarray) -> float:
        """Рассчитать силу тренда"""
        if len(closes) < 20:
            return 0
        
        # ADX-подобный расчет
        plus_dm = []
        minus_dm = []
        tr = []
        
        for i in range(1, min(len(closes), 20)):
            plus_dm.append(max(0, closes[i] - closes[i-1]))
            minus_dm.append(max(0, closes[i-1] - closes[i]))
            tr.append(abs(closes[i] - closes[i-1]))
        
        if not tr or sum(tr) == 0:
            return 0
        
        plus_di = sum(plus_dm) / sum(tr) * 100
        minus_di = sum(minus_dm) / sum(tr) * 100
        
        dx = abs(plus_di - minus_di) / (plus_di + minus_di) * 100 if (plus_di + minus_di) > 0 else 0
        
        # Направление тренда
        if plus_di > minus_di:
            return dx
        else:
            return -dx

class Predictor:
    """Предсказатель движения цены"""
    
    def __init__(self):
        self.pattern_recognizer = PatternRecognizer()
        self.sentiment_analyzer = SentimentAnalyzer()
        self.historical_predictions = []
    
    def predict(self, df: pd.DataFrame, timeframe: str = "1h") -> Prediction:
        """Сделать предсказание"""
        
        # Находим паттерны
        patterns = self.pattern_recognizer.find_patterns(df)
        
        # Анализируем настроение
        sentiment = self.sentiment_analyzer.analyze(df)
        
        # Рассчитываем вероятности
        prob_up, prob_down, prob_side = self._calculate_probabilities(
            df, patterns, sentiment
        )
        
        # Определяем направление
        if prob_up > prob_down and prob_up > prob_side:
            direction = "UP"
            confidence = prob_up
        elif prob_down > prob_up and prob_down > prob_side:
            direction = "DOWN"
            confidence = prob_down
        else:
            direction = "SIDEWAYS"
            confidence = prob_side
        
        # Рассчитываем цель
        target = self._calculate_target(df, direction, patterns)
        
        # Ключевые уровни
        levels = self._calculate_key_levels(df)
        
        # Обоснование
        reasoning = self._generate_reasoning(patterns, sentiment)
        
        prediction = Prediction(
            direction=direction,
            confidence=confidence,
            target_price=target,
            timeframe=timeframe,
            probability_up=prob_up,
            probability_down=prob_down,
            probability_sideways=prob_side,
            key_levels=levels,
            reasoning=reasoning
        )
        
        self.historical_predictions.append({
            'timestamp': datetime.now(),
            'prediction': prediction,
            'price': df['close'].iloc[-1]
        })
        
        return prediction
    
    def _calculate_probabilities(self, df: pd.DataFrame, 
                                  patterns: List[Pattern],
                                  sentiment: SentimentScore) -> Tuple[float, float, float]:
        """Рассчитать вероятности направления"""
        
        # Базовые вероятности
        prob_up = 33.33
        prob_down = 33.33
        prob_side = 33.34
        
        # Влияние паттернов
        for pattern in patterns:
            if pattern.pattern_type in [PatternType.DOUBLE_BOTTOM, 
                                        PatternType.FLAG_BULL,
                                        PatternType.TRIANGLE_ASCENDING]:
                prob_up += pattern.confidence * 0.3
                prob_down -= pattern.confidence * 0.15
            elif pattern.pattern_type in [PatternType.DOUBLE_TOP,
                                          PatternType.FLAG_BEAR,
                                          PatternType.TRIANGLE_DESCENDING]:
                prob_down += pattern.confidence * 0.3
                prob_up -= pattern.confidence * 0.15
        
        # Влияние настроения
        sentiment_factor = sentiment.overall / 100
        prob_up += sentiment_factor * 20
        prob_down -= sentiment_factor * 10
        
        # Нормализация
        total = prob_up + prob_down + prob_side
        prob_up = max(5, min(90, prob_up / total * 100))
        prob_down = max(5, min(90, prob_down / total * 100))
        prob_side = max(5, min(90, 100 - prob_up - prob_down))
        
        return prob_up, prob_down, prob_side
    
    def _calculate_target(self, df: pd.DataFrame, direction: str, 
                         patterns: List[Pattern]) -> float:
        """Рассчитать целевую цену"""
        
        current_price = df['close'].iloc[-1]
        
        # Если есть паттерн с целью, используем его
        for pattern in patterns:
            if pattern.confidence > 60:
                return pattern.target_price
        
        # Иначе рассчитываем на основе ATR
        atr = self._calculate_atr(df)
        
        if direction == "UP":
            return current_price + atr * 2
        elif direction == "DOWN":
            return current_price - atr * 2
        else:
            return current_price
    
    def _calculate_atr(self, df: pd.DataFrame, period: int = 14) -> float:
        """Рассчитать ATR"""
        if len(df) < period:
            return df['close'].std()
        
        highs = df['high'].values
        lows = df['low'].values
        closes = df['close'].values
        
        tr_list = []
        for i in range(1, len(closes)):
            tr = max(
                highs[i] - lows[i],
                abs(highs[i] - closes[i-1]),
                abs(lows[i] - closes[i-1])
            )
            tr_list.append(tr)
        
        return np.mean(tr_list[-period:]) if tr_list else 0
    
    def _calculate_key_levels(self, df: pd.DataFrame) -> Dict[str, float]:
        """Рассчитать ключевые уровни"""
        
        closes = df['close'].values
        highs = df['high'].values
        lows = df['low'].values
        
        # Уровни поддержки и сопротивления
        resistance = np.percentile(highs[-20:], 95)
        support = np.percentile(lows[-20:], 5)
        
        # Pivot point
        pivot = (highs[-1] + lows[-1] + closes[-1]) / 3
        
        # EMA
        ema_20 = pd.Series(closes).ewm(span=20).mean().iloc[-1]
        
        return {
            'resistance': resistance,
            'support': support,
            'pivot': pivot,
            'ema_20': ema_20
        }
    
    def _generate_reasoning(self, patterns: List[Pattern], 
                           sentiment: SentimentScore) -> List[str]:
        """Сгенерировать обоснование"""
        
        reasoning = []
        
        # Паттерны
        for pattern in patterns:
            if pattern.confidence > 50:
                reasoning.append(
                    f"Найден паттерн '{pattern.pattern_type.value}' "
                    f"(уверенность: {pattern.confidence}%)"
                )
        
        # Настроение
        if sentiment.overall > 50:
            reasoning.append(f"Сильный бычий настрой ({sentiment.overall:.0f}/100)")
        elif sentiment.overall > 20:
            reasoning.append(f"Умеренный бычий настрой ({sentiment.overall:.0f}/100)")
        elif sentiment.overall < -50:
            reasoning.append(f"Сильный медвежий настрой ({sentiment.overall:.0f}/100)")
        elif sentiment.overall < -20:
            reasoning.append(f"Умеренный медвежий настрой ({sentiment.overall:.0f}/100)")
        else:
            reasoning.append(f"Нейтральное настроение ({sentiment.overall:.0f}/100)")
        
        # Технические факторы
        if sentiment.technical > 30:
            reasoning.append("Технические индикаторы бычьи")
        elif sentiment.technical < -30:
            reasoning.append("Технические индикаторы медвежьи")
        
        if sentiment.volume > 20:
            reasoning.append("Высокий объем подтверждает движение")
        
        if sentiment.momentum > 50:
            reasoning.append("Сильный восходящий моментум")
        elif sentiment.momentum < -50:
            reasoning.append("Сильный нисходящий моментум")
        
        return reasoning
    
    def get_accuracy_stats(self) -> Dict:
        """Получить статистику точности предсказаний"""
        
        if len(self.historical_predictions) < 10:
            return {"message": "Недостаточно данных для статистики"}
        
        # Проверяем точность (упрощенно)
        correct = 0
        total = 0
        
        for i in range(len(self.historical_predictions) - 1):
            pred = self.historical_predictions[i]
            next_price = self.historical_predictions[i + 1]['price']
            
            predicted_direction = pred['prediction'].direction
            actual_direction = "UP" if next_price > pred['price'] else "DOWN" if next_price < pred['price'] else "SIDEWAYS"
            
            if predicted_direction == actual_direction:
                correct += 1
            total += 1
        
        accuracy = correct / total * 100 if total > 0 else 0
        
        return {
            "total_predictions": len(self.historical_predictions),
            "checked_predictions": total,
            "correct_predictions": correct,
            "accuracy": accuracy
        }

# Пример использования
def test_ai_analyzer():
    """Тест AI анализатора"""
    
    # Создаем тестовые данные
    np.random.seed(42)
    n = 100
    
    # Генерируем случайное блуждание с трендом
    trend = np.linspace(100, 120, n)
    noise = np.random.randn(n) * 2
    prices = trend + noise
    
    df = pd.DataFrame({
        'open': prices + np.random.randn(n) * 0.5,
        'high': prices + abs(np.random.randn(n)) * 2,
        'low': prices - abs(np.random.randn(n)) * 2,
        'close': prices,
        'volume': np.random.randint(1000, 10000, n)
    })
    
    # Анализируем
    predictor = Predictor()
    prediction = predictor.predict(df)
    
    print("=" * 50)
    print("🧠 AI PREDICTION RESULT")
    print("=" * 50)
    print(f"📊 Direction: {prediction.direction}")
    print(f"🎯 Confidence: {prediction.confidence:.1f}%")
    print(f"💰 Target Price: ${prediction.target_price:.2f}")
    print(f"📈 P(UP): {prediction.probability_up:.1f}%")
    print(f"📉 P(DOWN): {prediction.probability_down:.1f}%")
    print(f"➡️  P(SIDEWAYS): {prediction.probability_sideways:.1f}%")
    print("\n🔑 Key Levels:")
    for level, value in prediction.key_levels.items():
        print(f"   {level}: ${value:.2f}")
    print("\n💡 Reasoning:")
    for reason in prediction.reasoning:
        print(f"   • {reason}")

if __name__ == "__main__":
    test_ai_analyzer()
