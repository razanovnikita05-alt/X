#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    🤖 ULTIMATE CRYPTO TRADING BOT 🤖                          ║
║                                                                               ║
║  Умный бот для мониторинга и анализа криптовалют с AI-подобной логикой       ║
║  • Мониторинг 1000+ токенов в реальном времени                               ║
║  • Технический анализ (RSI, MACD, Bollinger, Volume)                         ║
║  • Проверка на скам (Honeypot, Rug Pull, Ликвидность)                        ║
║  • Сигналы на покупку/продажу с таймингом                                    ║
║  • Управление рисками и портфелем                                            ║
║  • Telegram уведомления                                                      ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

import requests
import json
import time
import asyncio
import aiohttp
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging
from collections import defaultdict
import threading
from decimal import Decimal
import hashlib
import hmac

# Telegram
from telegram import Bot
from telegram.constants import ParseMode

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('crypto_bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# КОНФИГУРАЦИЯ
# ═══════════════════════════════════════════════════════════════════════════════

class Config:
    """Конфигурация бота"""
    # Telegram
    TG_TOKEN = "7813361546:AAGnQ49TEIoOCgBfrOFRXbB27PgMr56_nec"
    CHAT_ID = "-1003689936622"
    
    # API Keys (добавьте свои для реальной торговли)
    BINANCE_API_KEY = ""
    BINANCE_SECRET = ""
    
    # Параметры торговли
    MIN_VOLUME_24H = 100000  # Минимальный объем 24ч ($)
    MAX_SLIPPAGE = 5  # Максимальный проскальзывание (%)
    MIN_LIQUIDITY = 50000  # Минимальная ликвидность ($)
    
    # Risk Management
    MAX_POSITION_SIZE = 100  # Макс позиция ($)
    STOP_LOSS = 5  # Стоп-лосс (%)
    TAKE_PROFIT_1 = 10  # Первый тейк-профит (%)
    TAKE_PROFIT_2 = 20  # Второй тейк-профит (%)
    TAKE_PROFIT_3 = 50  # Третий тейк-профит (%)
    
    # Таймфреймы для анализа
    TIMEFRAMES = ['1m', '5m', '15m', '1h', '4h', '1d']
    
    # Интервалы обновления
    SCAN_INTERVAL = 30  # Секунды между сканированиями
    ALERT_COOLDOWN = 300  # Кулдаун для повторных алертов (сек)

# ═══════════════════════════════════════════════════════════════════════════════
# DATA CLASSES
# ═══════════════════════════════════════════════════════════════════════════════

class SignalType(Enum):
    STRONG_BUY = "🟢 СИЛЬНАЯ ПОКУПКА"
    BUY = "🟡 ПОКУПКА"
    HOLD = "⚪ ДЕРЖАТЬ"
    SELL = "🟠 ПРОДАЖА"
    STRONG_SELL = "🔴 СИЛЬНАЯ ПРОДАЖА"
    WAIT = "⏳ ОЖИДАТЬ"

class RiskLevel(Enum):
    LOW = "🟢 НИЗКИЙ"
    MEDIUM = "🟡 СРЕДНИЙ"
    HIGH = "🔴 ВЫСОКИЙ"
    EXTREME = "⚫ ЭКСТРЕМАЛЬНЫЙ"

@dataclass
class TokenData:
    """Данные токена"""
    symbol: str
    name: str
    price: float
    price_change_1h: float = 0
    price_change_24h: float = 0
    volume_24h: float = 0
    market_cap: float = 0
    liquidity: float = 0
    holders: int = 0
    total_supply: float = 0
    circulating_supply: float = 0
    
    # Дополнительные метрики
    buy_pressure: float = 0  # Давление покупателей
    sell_pressure: float = 0  # Давление продавцов
    whale_activity: float = 0  # Активность китов
    gas_price: float = 0  # Цена газа

@dataclass
class TechnicalIndicators:
    """Технические индикаторы"""
    rsi: float = 50
    rsi_signal: str = "NEUTRAL"
    macd: float = 0
    macd_signal: float = 0
    macd_histogram: float = 0
    bb_upper: float = 0
    bb_middle: float = 0
    bb_lower: float = 0
    bb_position: str = "MIDDLE"
    ema_20: float = 0
    ema_50: float = 0
    ema_200: float = 0
    trend: str = "NEUTRAL"
    volume_sma: float = 0
    volume_ratio: float = 1
    support: float = 0
    resistance: float = 0
    
    # Сигналы
    golden_cross: bool = False
    death_cross: bool = False
    volume_spike: bool = False
    breakout: bool = False
    breakdown: bool = False

@dataclass
class ScamCheck:
    """Результат проверки на скам"""
    is_honeypot: bool = False
    is_rug_pull_risk: bool = False
    is_mintable: bool = False
    has_owner: bool = False
    owner_renounced: bool = False
    liquidity_locked: bool = False
    liquidity_lock_time: int = 0
    buy_tax: float = 0
    sell_tax: float = 0
    transfer_tax: float = 0
    hidden_mint: bool = False
    can_blacklist: bool = False
    score: int = 100  # 0-100, где 100 = безопасно
    warnings: List[str] = field(default_factory=list)
    
    @property
    def is_safe(self) -> bool:
        return self.score >= 70 and not self.is_honeypot

@dataclass
class TradingSignal:
    """Торговый сигнал"""
    symbol: str
    signal_type: SignalType
    entry_price: float
    target_prices: List[float]
    stop_loss: float
    risk_level: RiskLevel
    confidence: int  # 0-100
    timeframe: str
    indicators: TechnicalIndicators
    scam_check: ScamCheck
    token_data: TokenData
    reasoning: List[str]
    timestamp: datetime = field(default_factory=datetime.now)
    
    @property
    def risk_reward_ratio(self) -> float:
        if self.entry_price == 0:
            return 0
        risk = abs(self.entry_price - self.stop_loss)
        reward = abs(self.target_prices[0] - self.entry_price) if self.target_prices else 0
        return reward / risk if risk > 0 else 0

@dataclass
class Position:
    """Открытая позиция"""
    symbol: str
    entry_price: float
    quantity: float
    entry_time: datetime
    stop_loss: float
    take_profits: List[Tuple[float, float]]  # (price, % от позиции)
    invested: float
    current_price: float = 0
    unrealized_pnl: float = 0
    realized_pnl: float = 0
    status: str = "OPEN"
    partial_exits: List[Dict] = field(default_factory=list)

@dataclass
class Portfolio:
    """Портфель"""
    total_balance: float = 0
    available_usdt: float = 0
    positions: Dict[str, Position] = field(default_factory=dict)
    closed_positions: List[Position] = field(default_factory=list)
    total_pnl: float = 0
    daily_pnl: float = 0
    win_rate: float = 0
    total_trades: int = 0
    winning_trades: int = 0

# ═══════════════════════════════════════════════════════════════════════════════
# API КЛИЕНТЫ
# ═══════════════════════════════════════════════════════════════════════════════

class BinanceClient:
    """Клиент для Binance API"""
    BASE_URL = "https://api.binance.com"
    FAPI_URL = "https://fapi.binance.com"
    
    def __init__(self):
        self.session = requests.Session()
        self.last_prices = {}
        
    def get_all_tickers(self) -> List[Dict]:
        """Получить все тикеры"""
        try:
            response = self.session.get(f"{self.BASE_URL}/api/v3/ticker/24hr")
            return response.json()
        except Exception as e:
            logger.error(f"Error getting tickers: {e}")
            return []
    
    def get_klines(self, symbol: str, interval: str = "1h", limit: int = 100) -> List[List]:
        """Получить свечи"""
        try:
            params = {
                "symbol": symbol,
                "interval": interval,
                "limit": limit
            }
            response = self.session.get(f"{self.BASE_URL}/api/v3/klines", params=params)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting klines for {symbol}: {e}")
            return []
    
    def get_order_book(self, symbol: str, limit: int = 100) -> Dict:
        """Получить стакан"""
        try:
            params = {"symbol": symbol, "limit": limit}
            response = self.session.get(f"{self.BASE_URL}/api/v3/depth", params=params)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting order book for {symbol}: {e}")
            return {}
    
    def get_ticker_price(self, symbol: str) -> float:
        """Получить текущую цену"""
        try:
            response = self.session.get(f"{self.BASE_URL}/api/v3/ticker/price", 
                                      params={"symbol": symbol})
            data = response.json()
            price = float(data.get("price", 0))
            self.last_prices[symbol] = price
            return price
        except Exception as e:
            logger.error(f"Error getting price for {symbol}: {e}")
            return self.last_prices.get(symbol, 0)

class DexScreenerClient:
    """Клиент для DexScreener API (DEX токены)"""
    BASE_URL = "https://api.dexscreener.com"
    
    def __init__(self):
        self.session = requests.Session()
        
    def get_token_profiles(self) -> List[Dict]:
        """Получить профили токенов"""
        try:
            response = self.session.get(f"{self.BASE_URL}/token-profiles/latest/v1")
            return response.json()
        except Exception as e:
            logger.error(f"Error getting token profiles: {e}")
            return []
    
    def search_tokens(self, query: str) -> List[Dict]:
        """Поиск токенов"""
        try:
            response = self.session.get(f"{self.BASE_URL}/latest/dex/search", 
                                      params={"q": query})
            data = response.json()
            return data.get("pairs", [])
        except Exception as e:
            logger.error(f"Error searching tokens: {e}")
            return []
    
    def get_token_pairs(self, chain: str, token_address: str) -> List[Dict]:
        """Получить пары для токена"""
        try:
            url = f"{self.BASE_URL}/latest/dex/tokens/{token_address}"
            response = self.session.get(url)
            data = response.json()
            return data.get("pairs", [])
        except Exception as e:
            logger.error(f"Error getting token pairs: {e}")
            return []

class HoneypotChecker:
    """Проверка токенов на скам"""
    
    def __init__(self):
        self.session = requests.Session()
        self.cache = {}
        self.cache_ttl = 300  # 5 минут
    
    def check_token(self, chain: str, token_address: str) -> ScamCheck:
        """Проверить токен на скам"""
        cache_key = f"{chain}:{token_address}"
        
        # Проверяем кэш
        if cache_key in self.cache:
            cached, timestamp = self.cache[cache_key]
            if time.time() - timestamp < self.cache_ttl:
                return cached
        
        result = ScamCheck()
        
        try:
            # Используем Honeypot.is API (бесплатный)
            url = f"https://api.honeypot.is/v2/IsHoneypot"
            params = {
                "address": token_address,
                "chainID": self._get_chain_id(chain)
            }
            
            response = self.session.get(url, params=params, timeout=10)
            data = response.json()
            
            # Анализируем ответ
            result.is_honeypot = data.get("IsHoneypot", False)
            
            # Проверка налогов
            simulation = data.get("SimulationResult", {})
            result.buy_tax = simulation.get("BuyTax", 0)
            result.sell_tax = simulation.get("SellTax", 0)
            result.transfer_tax = simulation.get("TransferTax", 0)
            
            # Проверка владельца
            contract = data.get("ContractInfo", {})
            result.has_owner = contract.get("Owner", "") != ""
            result.owner_renounced = contract.get("OwnerRenounced", False)
            result.is_mintable = contract.get("Mintable", False)
            result.can_blacklist = contract.get("CanBlacklist", False)
            
            # Проверка ликвидности
            pair = data.get("Pair", {})
            result.liquidity_locked = pair.get("LiquidityLocked", False)
            result.liquidity_lock_time = pair.get("LiquidityLockTime", 0)
            
            # Расчет скора безопасности
            result.score = self._calculate_safety_score(result)
            
            # Генерация предупреждений
            result.warnings = self._generate_warnings(result)
            
            # Кэшируем результат
            self.cache[cache_key] = (result, time.time())
            
        except Exception as e:
            logger.error(f"Error checking honeypot: {e}")
            result.warnings.append("⚠️ Не удалось проверить токен на скам")
            result.score = 50  # Нейтральный скор при ошибке
        
        return result
    
    def _get_chain_id(self, chain: str) -> int:
        """Получить ID сети"""
        chains = {
            "ethereum": 1,
            "bsc": 56,
            "polygon": 137,
            "arbitrum": 42161,
            "optimism": 10,
            "base": 8453,
            "avalanche": 43114,
            "fantom": 250
        }
        return chains.get(chain.lower(), 1)
    
    def _calculate_safety_score(self, check: ScamCheck) -> int:
        """Рассчитать скор безопасности"""
        score = 100
        
        if check.is_honeypot:
            return 0
        
        # Налоги
        if check.buy_tax > 10:
            score -= 20
        elif check.buy_tax > 5:
            score -= 10
        
        if check.sell_tax > 10:
            score -= 25
        elif check.sell_tax > 5:
            score -= 15
        
        # Владение
        if check.has_owner and not check.owner_renounced:
            score -= 15
        
        if check.is_mintable:
            score -= 10
        
        if check.can_blacklist:
            score -= 10
        
        # Ликвидность
        if not check.liquidity_locked:
            score -= 15
        elif check.liquidity_lock_time < 30:  # Меньше 30 дней
            score -= 5
        
        return max(0, score)
    
    def _generate_warnings(self, check: ScamCheck) -> List[str]:
        """Сгенерировать предупреждения"""
        warnings = []
        
        if check.is_honeypot:
            warnings.append("🚨 HONEYPOT! НЕ ПОКУПАТЬ!")
        
        if check.buy_tax > 5:
            warnings.append(f"⚠️ Высокий налог на покупку: {check.buy_tax}%")
        
        if check.sell_tax > 5:
            warnings.append(f"🚨 Высокий налог на продажу: {check.sell_tax}%")
        
        if check.has_owner and not check.owner_renounced:
            warnings.append("⚠️ Владелец не отказался от прав")
        
        if check.is_mintable:
            warnings.append("⚠️ Токен можно минтить (инфляция)")
        
        if check.can_blacklist:
            warnings.append("⚠️ Возможен черный список адресов")
        
        if not check.liquidity_locked:
            warnings.append("🔴 Ликвидность НЕ заблокирована (риск rug pull)")
        elif check.liquidity_lock_time < 30:
            warnings.append(f"⚠️ Ликвидность заблокирована на {check.liquidity_lock_time} дней")
        
        return warnings

# ═══════════════════════════════════════════════════════════════════════════════
# ТЕХНИЧЕСКИЙ АНАЛИЗ
# ═══════════════════════════════════════════════════════════════════════════════

class TechnicalAnalyzer:
    """Технический анализ"""
    
    @staticmethod
    def calculate_rsi(prices: pd.Series, period: int = 14) -> float:
        """Рассчитать RSI"""
        if len(prices) < period:
            return 50
        
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi.iloc[-1] if not pd.isna(rsi.iloc[-1]) else 50
    
    @staticmethod
    def calculate_macd(prices: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[float, float, float]:
        """Рассчитать MACD"""
        if len(prices) < slow:
            return 0, 0, 0
        
        exp1 = prices.ewm(span=fast).mean()
        exp2 = prices.ewm(span=slow).mean()
        macd = exp1 - exp2
        signal_line = macd.ewm(span=signal).mean()
        histogram = macd - signal_line
        
        return macd.iloc[-1], signal_line.iloc[-1], histogram.iloc[-1]
    
    @staticmethod
    def calculate_bollinger_bands(prices: pd.Series, period: int = 20, std_dev: int = 2) -> Tuple[float, float, float]:
        """Рассчитать Bollinger Bands"""
        if len(prices) < period:
            return 0, 0, 0
        
        sma = prices.rolling(window=period).mean()
        std = prices.rolling(window=period).std()
        
        upper = sma + (std * std_dev)
        lower = sma - (std * std_dev)
        
        return upper.iloc[-1], sma.iloc[-1], lower.iloc[-1]
    
    @staticmethod
    def calculate_ema(prices: pd.Series, period: int) -> float:
        """Рассчитать EMA"""
        if len(prices) < period:
            return prices.iloc[-1] if len(prices) > 0 else 0
        
        ema = prices.ewm(span=period).mean()
        return ema.iloc[-1]
    
    @staticmethod
    def calculate_volume_analysis(volumes: pd.Series, prices: pd.Series) -> Tuple[float, bool]:
        """Анализ объемов"""
        if len(volumes) < 20:
            return 1, False
        
        volume_sma = volumes.rolling(window=20).mean()
        current_volume = volumes.iloc[-1]
        avg_volume = volume_sma.iloc[-1]
        
        volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
        volume_spike = volume_ratio > 2  # Объем в 2 раза выше среднего
        
        return volume_ratio, volume_spike
    
    @staticmethod
    def find_support_resistance(prices: pd.Series, window: int = 10) -> Tuple[float, float]:
        """Найти уровни поддержки и сопротивления"""
        if len(prices) < window * 2:
            return prices.min() if len(prices) > 0 else 0, prices.max() if len(prices) > 0 else 0
        
        # Простой метод: локальные минимумы и максимумы
        local_min = prices.rolling(window=window, center=True).min()
        local_max = prices.rolling(window=window, center=True).max()
        
        support = local_min.dropna().iloc[-window:].mean()
        resistance = local_max.dropna().iloc[-window:].mean()
        
        return support, resistance
    
    def analyze(self, klines: List[List]) -> TechnicalIndicators:
        """Полный технический анализ"""
        if not klines or len(klines) < 50:
            return TechnicalIndicators()
        
        # Преобразуем данные
        df = pd.DataFrame(klines, columns=[
            'timestamp', 'open', 'high', 'low', 'close', 'volume',
            'close_time', 'quote_volume', 'trades', 'taker_buy_base',
            'taker_buy_quote', 'ignore'
        ])
        
        df['close'] = pd.to_numeric(df['close'])
        df['volume'] = pd.to_numeric(df['volume'])
        df['high'] = pd.to_numeric(df['high'])
        df['low'] = pd.to_numeric(df['low'])
        
        prices = df['close']
        volumes = df['volume']
        
        indicators = TechnicalIndicators()
        
        # RSI
        indicators.rsi = self.calculate_rsi(prices)
        if indicators.rsi > 70:
            indicators.rsi_signal = "OVERBOUGHT"
        elif indicators.rsi < 30:
            indicators.rsi_signal = "OVERSOLD"
        else:
            indicators.rsi_signal = "NEUTRAL"
        
        # MACD
        indicators.macd, indicators.macd_signal, indicators.macd_histogram = \
            self.calculate_macd(prices)
        
        # Bollinger Bands
        indicators.bb_upper, indicators.bb_middle, indicators.bb_lower = \
            self.calculate_bollinger_bands(prices)
        
        # Позиция относительно BB
        current_price = prices.iloc[-1]
        if current_price > indicators.bb_upper:
            indicators.bb_position = "ABOVE"
        elif current_price < indicators.bb_lower:
            indicators.bb_position = "BELOW"
        else:
            indicators.bb_position = "MIDDLE"
        
        # EMA
        indicators.ema_20 = self.calculate_ema(prices, 20)
        indicators.ema_50 = self.calculate_ema(prices, 50)
        indicators.ema_200 = self.calculate_ema(prices, 200)
        
        # Тренд
        if indicators.ema_20 > indicators.ema_50 > indicators.ema_200:
            indicators.trend = "STRONG_UPTREND"
        elif indicators.ema_20 > indicators.ema_50:
            indicators.trend = "UPTREND"
        elif indicators.ema_20 < indicators.ema_50 < indicators.ema_200:
            indicators.trend = "STRONG_DOWNTREND"
        elif indicators.ema_20 < indicators.ema_50:
            indicators.trend = "DOWNTREND"
        else:
            indicators.trend = "SIDEWAYS"
        
        # Golden/Death Cross
        indicators.golden_cross = (
            indicators.ema_20 > indicators.ema_50 and 
            self.calculate_ema(prices[:-1], 20) <= self.calculate_ema(prices[:-1], 50)
        )
        indicators.death_cross = (
            indicators.ema_20 < indicators.ema_50 and 
            self.calculate_ema(prices[:-1], 20) >= self.calculate_ema(prices[:-1], 50)
        )
        
        # Объемы
        indicators.volume_ratio, indicators.volume_spike = \
            self.calculate_volume_analysis(volumes, prices)
        
        # Support/Resistance
        indicators.support, indicators.resistance = \
            self.find_support_resistance(prices)
        
        # Breakout/Breakdown
        if current_price > indicators.resistance * 1.02:
            indicators.breakout = True
        elif current_price < indicators.support * 0.98:
            indicators.breakdown = True
        
        return indicators

# ═══════════════════════════════════════════════════════════════════════════════
# СИГНАЛЬНАЯ СИСТЕМА
# ═══════════════════════════════════════════════════════════════════════════════

class SignalEngine:
    """Движок генерации сигналов"""
    
    def __init__(self):
        self.analyzer = TechnicalAnalyzer()
        self.honeypot_checker = HoneypotChecker()
        self.last_signals = {}
    
    def generate_signal(self, symbol: str, klines: List[List], 
                       token_data: TokenData = None) -> Optional[TradingSignal]:
        """Сгенерировать торговый сигнал"""
        
        # Проверяем кулдаун
        if symbol in self.last_signals:
            last_time = self.last_signals[symbol]
            if (datetime.now() - last_time).seconds < Config.ALERT_COOLDOWN:
                return None
        
        # Технический анализ
        indicators = self.analyzer.analyze(klines)
        
        # Определяем тип сигнала
        signal_type, confidence, reasoning = self._evaluate_signal(indicators, token_data)
        
        if signal_type in [SignalType.WAIT, SignalType.HOLD]:
            return None
        
        # Проверка на скам для DEX токенов
        scam_check = ScamCheck()
        if token_data and hasattr(token_data, 'address'):
            scam_check = self.honeypot_checker.check_token(
                getattr(token_data, 'chain', 'bsc'),
                token_data.address
            )
            
            if not scam_check.is_safe:
                reasoning.append("⚠️ Токен не прошел проверку безопасности")
                confidence = max(0, confidence - 30)
        
        # Рассчитываем уровни
        current_price = float(klines[-1][4]) if klines else 0
        
        entry_price = current_price
        stop_loss = self._calculate_stop_loss(indicators, current_price, signal_type)
        targets = self._calculate_targets(indicators, current_price, signal_type)
        
        # Определяем риск
        risk_level = self._calculate_risk_level(indicators, scam_check)
        
        # Создаем сигнал
        signal = TradingSignal(
            symbol=symbol,
            signal_type=signal_type,
            entry_price=entry_price,
            target_prices=targets,
            stop_loss=stop_loss,
            risk_level=risk_level,
            confidence=confidence,
            timeframe="1h",
            indicators=indicators,
            scam_check=scam_check,
            token_data=token_data or TokenData(symbol=symbol, name=symbol, price=current_price),
            reasoning=reasoning
        )
        
        # Обновляем кулдаун
        self.last_signals[symbol] = datetime.now()
        
        return signal
    
    def _evaluate_signal(self, ind: TechnicalIndicators, 
                         token_data: TokenData) -> Tuple[SignalType, int, List[str]]:
        """Оценить и сгенерировать сигнал"""
        
        score = 0
        confidence = 50
        reasons = []
        
        # RSI анализ
        if ind.rsi < 30:
            score += 2
            confidence += 10
            reasons.append(f"📊 RSI перепродан ({ind.rsi:.1f})")
        elif ind.rsi < 40:
            score += 1
            confidence += 5
            reasons.append(f"📊 RSI близок к перепроданности ({ind.rsi:.1f})")
        elif ind.rsi > 70:
            score -= 2
            confidence -= 10
            reasons.append(f"📊 RSI перекуплен ({ind.rsi:.1f})")
        elif ind.rsi > 60:
            score -= 1
            confidence -= 5
            reasons.append(f"📊 RSI близок к перекупленности ({ind.rsi:.1f})")
        
        # MACD анализ
        if ind.macd > ind.macd_signal and ind.macd_histogram > 0:
            score += 2
            confidence += 10
            reasons.append("📈 MACD бычий кросс")
        elif ind.macd < ind.macd_signal and ind.macd_histogram < 0:
            score -= 2
            confidence -= 10
            reasons.append("📉 MACD медвежий кросс")
        
        # Bollinger Bands
        if ind.bb_position == "BELOW":
            score += 2
            confidence += 10
            reasons.append("📊 Цена ниже нижней BB (перепродан)")
        elif ind.bb_position == "ABOVE":
            score -= 2
            confidence -= 10
            reasons.append("📊 Цена выше верхней BB (перекуплен)")
        
        # Тренд
        if ind.trend == "STRONG_UPTREND":
            score += 2
            confidence += 15
            reasons.append("🚀 Сильный восходящий тренд")
        elif ind.trend == "UPTREND":
            score += 1
            confidence += 10
            reasons.append("📈 Восходящий тренд")
        elif ind.trend == "STRONG_DOWNTREND":
            score -= 2
            confidence -= 15
            reasons.append("🔻 Сильный нисходящий тренд")
        elif ind.trend == "DOWNTREND":
            score -= 1
            confidence -= 10
            reasons.append("📉 Нисходящий тренд")
        
        # Объем
        if ind.volume_spike:
            score += 1
            confidence += 10
            reasons.append(f"📊 Всплеск объема (x{ind.volume_ratio:.1f})")
        
        # Golden/Death Cross
        if ind.golden_cross:
            score += 3
            confidence += 15
            reasons.append("✨ Golden Cross! Сильный бычий сигнал")
        elif ind.death_cross:
            score -= 3
            confidence -= 15
            reasons.append("💀 Death Cross! Сильный медвежий сигнал")
        
        # Breakout/Breakdown
        if ind.breakout:
            score += 2
            confidence += 10
            reasons.append("🚀 Пробой сопротивления!")
        elif ind.breakdown:
            score -= 2
            confidence -= 10
            reasons.append("🔻 Пробой поддержки!")
        
        # EMA позиция
        current_price = ind.ema_20  # Приблизительно
        if ind.ema_20 > ind.ema_50:
            score += 1
            reasons.append("📈 EMA20 > EMA50")
        
        # Определяем тип сигнала
        if score >= 4 and confidence >= 70:
            return SignalType.STRONG_BUY, min(confidence, 95), reasons
        elif score >= 2 and confidence >= 60:
            return SignalType.BUY, min(confidence, 85), reasons
        elif score <= -4 and confidence <= 30:
            return SignalType.STRONG_SELL, min(100 - confidence, 95), reasons
        elif score <= -2 and confidence <= 40:
            return SignalType.SELL, min(100 - confidence, 85), reasons
        elif abs(score) < 1:
            return SignalType.HOLD, 50, reasons
        else:
            return SignalType.WAIT, 50, reasons
    
    def _calculate_stop_loss(self, ind: TechnicalIndicators, 
                            entry: float, signal_type: SignalType) -> float:
        """Рассчитать стоп-лосс"""
        
        if "BUY" in signal_type.value:
            # Для лонга
            if ind.support > 0 and ind.support < entry:
                return ind.support * 0.98  # Чуть ниже поддержки
            else:
                return entry * (1 - Config.STOP_LOSS / 100)
        else:
            # Для шорта
            if ind.resistance > 0 and ind.resistance > entry:
                return ind.resistance * 1.02
            else:
                return entry * (1 + Config.STOP_LOSS / 100)
    
    def _calculate_targets(self, ind: TechnicalIndicators, 
                          entry: float, signal_type: SignalType) -> List[float]:
        """Рассчитать цели"""
        
        targets = []
        
        if "BUY" in signal_type.value:
            # TP1 - ближайшее сопротивление или %
            tp1 = ind.resistance if ind.resistance > entry else entry * (1 + Config.TAKE_PROFIT_1 / 100)
            tp2 = entry * (1 + Config.TAKE_PROFIT_2 / 100)
            tp3 = entry * (1 + Config.TAKE_PROFIT_3 / 100)
        else:
            tp1 = ind.support if ind.support < entry else entry * (1 - Config.TAKE_PROFIT_1 / 100)
            tp2 = entry * (1 - Config.TAKE_PROFIT_2 / 100)
            tp3 = entry * (1 - Config.TAKE_PROFIT_3 / 100)
        
        targets = [tp1, tp2, tp3]
        return targets
    
    def _calculate_risk_level(self, ind: TechnicalIndicators, 
                              scam_check: ScamCheck) -> RiskLevel:
        """Рассчитать уровень риска"""
        
        risk_score = 0
        
        # Волатильность (по ширине BB)
        if ind.bb_upper > 0 and ind.bb_lower > 0:
            bb_width = (ind.bb_upper - ind.bb_lower) / ind.bb_middle
            if bb_width > 0.1:
                risk_score += 2
            elif bb_width > 0.05:
                risk_score += 1
        
        # Тренд
        if ind.trend == "SIDEWAYS":
            risk_score += 1
        
        # RSI экстремум
        if ind.rsi < 20 or ind.rsi > 80:
            risk_score += 1
        
        # Проверка на скам
        if scam_check.score < 50:
            risk_score += 3
        elif scam_check.score < 70:
            risk_score += 1
        
        if risk_score >= 4:
            return RiskLevel.EXTREME
        elif risk_score >= 2:
            return RiskLevel.HIGH
        elif risk_score >= 1:
            return RiskLevel.MEDIUM
        else:
            return RiskLevel.LOW

# ═══════════════════════════════════════════════════════════════════════════════
# TELEGRAM БОТ
# ═══════════════════════════════════════════════════════════════════════════════

class TelegramNotifier:
    """Уведомления в Telegram"""
    
    def __init__(self, token: str, chat_id: str):
        self.token = token
        self.chat_id = chat_id
        self.bot = Bot(token=token)
        self.message_queue = asyncio.Queue()
        self.running = False
    
    async def start(self):
        """Запустить обработчик очереди"""
        self.running = True
        asyncio.create_task(self._process_queue())
    
    async def _process_queue(self):
        """Обработка очереди сообщений"""
        while self.running:
            try:
                message = await asyncio.wait_for(self.message_queue.get(), timeout=1)
                await self._send_message(message)
                await asyncio.sleep(0.1)  # Rate limiting
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error processing queue: {e}")
    
    async def _send_message(self, message: str):
        """Отправить сообщение"""
        try:
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=message,
                parse_mode=ParseMode.HTML,
                disable_web_page_preview=True
            )
        except Exception as e:
            logger.error(f"Error sending telegram message: {e}")
    
    async def send_signal(self, signal: TradingSignal):
        """Отправить сигнал"""
        
        emoji = "🚀" if "BUY" in signal.signal_type.value else "🔻"
        
        message = f"""
{emoji} <b>{signal.signal_type.value}</b> {emoji}

<b>💎 Токен:</b> <code>{signal.symbol}</code>
<b>📊 Уверенность:</b> {signal.confidence}%
<b>⚠️ Риск:</b> {signal.risk_level.value}
<b>⏱ Таймфрейм:</b> {signal.timeframe}

<b>💰 Цена входа:</b> <code>${signal.entry_price:.8f}</code>
<b>🛑 Стоп-лосс:</b> <code>${signal.stop_loss:.8f}</code> ({((signal.stop_loss/signal.entry_price-1)*100):.2f}%)

<b>🎯 Цели:</b>
🥇 TP1: <code>${signal.target_prices[0]:.8f}</code> (+{((signal.target_prices[0]/signal.entry_price-1)*100):.2f}%)
🥈 TP2: <code>${signal.target_prices[1]:.8f}</code> (+{((signal.target_prices[1]/signal.entry_price-1)*100):.2f}%)
🥉 TP3: <code>${signal.target_prices[2]:.8f}</code> (+{((signal.target_prices[2]/signal.entry_price-1)*100):.2f}%)

<b>📈 Risk/Reward:</b> 1:{signal.risk_reward_ratio:.2f}

<b>🔍 Индикаторы:</b>
• RSI: {signal.indicators.rsi:.1f} ({signal.indicators.rsi_signal})
• MACD: {signal.indicators.macd:.6f}
• Тренд: {signal.indicators.trend}
• Объем: x{signal.indicators.volume_ratio:.1f} {'🚀' if signal.indicators.volume_spike else ''}
• EMA20/50/200: {signal.indicators.ema_20:.6f} / {signal.indicators.ema_50:.6f} / {signal.indicators.ema_200:.6f}

<b>💡 Обоснование:</b>
"""
        for reason in signal.reasoning:
            message += f"• {reason}\n"
        
        # Проверка на скам
        if signal.scam_check.warnings:
            message += "\n<b>⚠️ Предупреждения безопасности:</b>\n"
            for warning in signal.scam_check.warnings:
                message += f"• {warning}\n"
        
        message += f"\n<b>🛡️ Safety Score:</b> {signal.scam_check.score}/100\n"
        
        if signal.scam_check.is_safe:
            message += "\n✅ <b>Токен прошел проверку безопасности</b>"
        else:
            message += "\n🚨 <b>ВНИМАНИЕ: Токен не прошел проверку безопасности!</b>"
        
        message += f"\n\n⏰ <i>{signal.timestamp.strftime('%Y-%m-%d %H:%M:%S')}</i>"
        
        await self.message_queue.put(message)
    
    async def send_portfolio_update(self, portfolio: Portfolio):
        """Отправить обновление портфеля"""
        
        message = f"""
<b>📊 ОБНОВЛЕНИЕ ПОРТФЕЛЯ</b>

<b>💰 Общий баланс:</b> ${portfolio.total_balance:.2f}
<b>💵 Доступно USDT:</b> ${portfolio.available_usdt:.2f}

<b>📈 P&L:</b>
• Общий P&L: <code>${portfolio.total_pnl:+.2f}</code>
• Дневной P&L: <code>${portfolio.daily_pnl:+.2f}</code>
• Win Rate: {portfolio.win_rate:.1f}% ({portfolio.winning_trades}/{portfolio.total_trades})

<b>📋 Открытые позиции ({len(portfolio.positions)}):</b>
"""
        
        for symbol, pos in portfolio.positions.items():
            pnl_pct = ((pos.current_price / pos.entry_price - 1) * 100) if pos.entry_price > 0 else 0
            message += f"• {symbol}: {pos.quantity:.4f} @ ${pos.entry_price:.6f} | P&L: {pnl_pct:+.2f}%\n"
        
        await self.message_queue.put(message)
    
    async def send_alert(self, title: str, message: str):
        """Отправить алерт"""
        full_message = f"<b>🔔 {title}</b>\n\n{message}"
        await self.message_queue.put(full_message)
    
    async def send_startup_message(self):
        """Отправить сообщение о запуске"""
        message = """
🤖 <b>ULTIMATE CRYPTO TRADING BOT ЗАПУЩЕН!</b> 🤖

✅ Мониторинг 1000+ токенов активирован
✅ Технический анализ (RSI, MACD, BB, EMA)
✅ Проверка на скам (Honeypot, Rug Pull)
✅ Risk Management
✅ Telegram уведомления

<b>Команды:</b>
/portfolio - Показать портфель
/signals - Последние сигналы
/stats - Статистика
/settings - Настройки

🚀 <i>Готов к заработку!</i>
"""
        await self.message_queue.put(message)

# ═══════════════════════════════════════════════════════════════════════════════
# ПОРТФЕЛЬ И УПРАВЛЕНИЕ
# ═══════════════════════════════════════════════════════════════════════════════

class PortfolioManager:
    """Управление портфелем"""
    
    def __init__(self):
        self.portfolio = Portfolio()
        self.load_portfolio()
    
    def load_portfolio(self):
        """Загрузить портфель из файла"""
        try:
            with open('portfolio.json', 'r') as f:
                data = json.load(f)
                self.portfolio.total_balance = data.get('total_balance', 0)
                self.portfolio.available_usdt = data.get('available_usdt', 1000)
                self.portfolio.total_pnl = data.get('total_pnl', 0)
                self.portfolio.total_trades = data.get('total_trades', 0)
                self.portfolio.winning_trades = data.get('winning_trades', 0)
        except FileNotFoundError:
            # Новый портфель
            self.portfolio.available_usdt = 1000  # Начальный баланс
            self.save_portfolio()
    
    def save_portfolio(self):
        """Сохранить портфель"""
        data = {
            'total_balance': self.portfolio.total_balance,
            'available_usdt': self.portfolio.available_usdt,
            'total_pnl': self.portfolio.total_pnl,
            'total_trades': self.portfolio.total_trades,
            'winning_trades': self.portfolio.winning_trades,
            'positions': {
                sym: {
                    'symbol': pos.symbol,
                    'entry_price': pos.entry_price,
                    'quantity': pos.quantity,
                    'invested': pos.invested,
                    'stop_loss': pos.stop_loss,
                    'take_profits': pos.take_profits
                }
                for sym, pos in self.portfolio.positions.items()
            }
        }
        with open('portfolio.json', 'w') as f:
            json.dump(data, f, indent=2)
    
    def open_position(self, signal: TradingSignal, amount_usdt: float) -> bool:
        """Открыть позицию"""
        
        if amount_usdt > self.portfolio.available_usdt:
            logger.warning(f"Недостаточно средств для открытия позиции {signal.symbol}")
            return False
        
        quantity = amount_usdt / signal.entry_price
        
        position = Position(
            symbol=signal.symbol,
            entry_price=signal.entry_price,
            quantity=quantity,
            entry_time=datetime.now(),
            stop_loss=signal.stop_loss,
            take_profits=[
                (signal.target_prices[0], 0.3),  # 30% на TP1
                (signal.target_prices[1], 0.3),  # 30% на TP2
                (signal.target_prices[2], 0.4),  # 40% на TP3
            ],
            invested=amount_usdt,
            current_price=signal.entry_price
        )
        
        self.portfolio.positions[signal.symbol] = position
        self.portfolio.available_usdt -= amount_usdt
        self.save_portfolio()
        
        logger.info(f"Открыта позиция {signal.symbol}: {quantity:.4f} @ ${signal.entry_price:.6f}")
        return True
    
    def close_position(self, symbol: str, price: float, reason: str = "manual") -> Optional[float]:
        """Закрыть позицию"""
        
        if symbol not in self.portfolio.positions:
            return None
        
        position = self.portfolio.positions.pop(symbol)
        
        # Рассчитываем P&L
        pnl = (price - position.entry_price) * position.quantity
        position.realized_pnl = pnl
        position.current_price = price
        position.status = "CLOSED"
        
        # Обновляем баланс
        self.portfolio.available_usdt += position.invested + pnl
        self.portfolio.total_pnl += pnl
        self.portfolio.total_trades += 1
        
        if pnl > 0:
            self.portfolio.winning_trades += 1
        
        self.portfolio.win_rate = (
            self.portfolio.winning_trades / self.portfolio.total_trades * 100
            if self.portfolio.total_trades > 0 else 0
        )
        
        self.portfolio.closed_positions.append(position)
        self.save_portfolio()
        
        logger.info(f"Закрыта позиция {symbol}: P&L = ${pnl:.2f} ({reason})")
        return pnl
    
    def update_prices(self, prices: Dict[str, float]):
        """Обновить цены позиций"""
        
        for symbol, price in prices.items():
            if symbol in self.portfolio.positions:
                pos = self.portfolio.positions[symbol]
                pos.current_price = price
                pos.unrealized_pnl = (price - pos.entry_price) * pos.quantity
                
                # Проверка стоп-лосса
                if price <= pos.stop_loss:
                    logger.info(f"Стоп-лосс сработан для {symbol}")
                    # В реальном боте здесь был бы вызов close_position
                
                # Проверка тейк-профитов
                for tp_price, tp_pct in pos.take_profits:
                    if price >= tp_price and tp_pct > 0:
                        logger.info(f"Тейк-профит достигнут для {symbol}: ${tp_price}")
                        # Частичное закрытие
    
    def get_summary(self) -> Dict:
        """Получить сводку портфеля"""
        
        total_value = self.portfolio.available_usdt
        unrealized_pnl = 0
        
        for pos in self.portfolio.positions.values():
            position_value = pos.quantity * pos.current_price
            total_value += position_value
            unrealized_pnl += pos.unrealized_pnl
        
        return {
            'total_value': total_value,
            'available_usdt': self.portfolio.available_usdt,
            'unrealized_pnl': unrealized_pnl,
            'realized_pnl': self.portfolio.total_pnl,
            'total_pnl': unrealized_pnl + self.portfolio.total_pnl,
            'open_positions': len(self.portfolio.positions),
            'win_rate': self.portfolio.win_rate,
            'total_trades': self.portfolio.total_trades
        }

# ═══════════════════════════════════════════════════════════════════════════════
# ОСНОВНОЙ БОТ
# ═══════════════════════════════════════════════════════════════════════════════

class CryptoTradingBot:
    """Главный класс торгового бота"""
    
    def __init__(self):
        self.binance = BinanceClient()
        self.dexscreener = DexScreenerClient()
        self.signal_engine = SignalEngine()
        self.portfolio_manager = PortfolioManager()
        self.telegram = TelegramNotifier(Config.TG_TOKEN, Config.CHAT_ID)
        
        self.running = False
        self.watched_symbols = set()
        self.signals_history = []
        self.top_gainers = []
        self.top_losers = []
        
        # Статистика
        self.scanned_count = 0
        self.signals_generated = 0
        self.start_time = None
    
    async def start(self):
        """Запустить бота"""
        self.running = True
        self.start_time = datetime.now()
        
        logger.info("=" * 60)
        logger.info("🚀 ULTIMATE CRYPTO TRADING BOT ЗАПУЩЕН!")
        logger.info("=" * 60)
        
        # Запускаем Telegram
        await self.telegram.start()
        await self.telegram.send_startup_message()
        
        # Запускаем задачи
        tasks = [
            self._scanning_loop(),
            self._portfolio_loop(),
            self._top_movers_loop(),
            self._alert_loop(),
        ]
        
        await asyncio.gather(*tasks)
    
    async def _scanning_loop(self):
        """Основной цикл сканирования"""
        
        while self.running:
            try:
                logger.info("🔍 Начинаю сканирование рынка...")
                
                # Получаем все тикеры с Binance
                tickers = self.binance.get_all_tickers()
                
                # Фильтруем USDT пары с достаточным объемом
                usdt_pairs = [
                    t for t in tickers 
                    if t.get('symbol', '').endswith('USDT') and
                    float(t.get('volume', 0)) * float(t.get('lastPrice', 0)) > Config.MIN_VOLUME_24H
                ]
                
                # Сортируем по объему
                usdt_pairs.sort(key=lambda x: float(x.get('quoteVolume', 0)), reverse=True)
                
                # Берем топ 100 по объему
                top_pairs = usdt_pairs[:100]
                
                logger.info(f"Найдено {len(top_pairs)} пар для анализа")
                
                # Анализируем каждую пару
                for ticker in top_pairs:
                    if not self.running:
                        break
                    
                    symbol = ticker['symbol']
                    
                    try:
                        # Получаем свечи
                        klines = self.binance.get_klines(symbol, '1h', 100)
                        
                        if not klines or len(klines) < 50:
                            continue
                        
                        # Создаем данные токена
                        token_data = TokenData(
                            symbol=symbol,
                            name=symbol.replace('USDT', ''),
                            price=float(ticker.get('lastPrice', 0)),
                            price_change_1h=float(ticker.get('priceChangePercent', 0)),
                            price_change_24h=float(ticker.get('priceChangePercent', 0)),
                            volume_24h=float(ticker.get('quoteVolume', 0)),
                            market_cap=0
                        )
                        
                        # Генерируем сигнал
                        signal = self.signal_engine.generate_signal(symbol, klines, token_data)
                        
                        if signal and signal.signal_type in [SignalType.STRONG_BUY, SignalType.BUY]:
                            self.signals_history.append(signal)
                            self.signals_generated += 1
                            
                            # Отправляем в Telegram
                            await self.telegram.send_signal(signal)
                            
                            logger.info(f"🚨 СИГНАЛ: {signal.signal_type.value} для {symbol} (уверенность: {signal.confidence}%)")
                        
                        self.scanned_count += 1
                        
                        # Небольшая задержка между запросами
                        await asyncio.sleep(0.1)
                        
                    except Exception as e:
                        logger.error(f"Error analyzing {symbol}: {e}")
                        continue
                
                logger.info(f"✅ Сканирование завершено. Просканировано: {self.scanned_count}, Сигналов: {self.signals_generated}")
                
                # Ждем перед следующим сканированием
                await asyncio.sleep(Config.SCAN_INTERVAL)
                
            except Exception as e:
                logger.error(f"Error in scanning loop: {e}")
                await asyncio.sleep(10)
    
    async def _portfolio_loop(self):
        """Цикл обновления портфеля"""
        
        while self.running:
            try:
                # Обновляем цены для открытых позиций
                if self.portfolio_manager.portfolio.positions:
                    prices = {}
                    for symbol in self.portfolio_manager.portfolio.positions.keys():
                        price = self.binance.get_ticker_price(symbol)
                        if price > 0:
                            prices[symbol] = price
                    
                    self.portfolio_manager.update_prices(prices)
                    
                    # Отправляем обновление каждые 15 минут
                    if int(time.time()) % 900 < 60:
                        await self.telegram.send_portfolio_update(
                            self.portfolio_manager.portfolio
                        )
                
                await asyncio.sleep(30)
                
            except Exception as e:
                logger.error(f"Error in portfolio loop: {e}")
                await asyncio.sleep(10)
    
    async def _top_movers_loop(self):
        """Цикл отслеживания топ движений"""
        
        while self.running:
            try:
                tickers = self.binance.get_all_tickers()
                usdt_pairs = [t for t in tickers if t.get('symbol', '').endswith('USDT')]
                
                # Топ растущих
                gainers = sorted(
                    usdt_pairs, 
                    key=lambda x: float(x.get('priceChangePercent', 0)), 
                    reverse=True
                )[:10]
                
                # Топ падающих
                losers = sorted(
                    usdt_pairs, 
                    key=lambda x: float(x.get('priceChangePercent', 0))
                )[:10]
                
                self.top_gainers = gainers
                self.top_losers = losers
                
                # Отправляем раз в час
                if int(time.time()) % 3600 < 60:
                    message = "📊 <b>ТОП ДВИЖЕНИЯ ЗА ЧАС</b>\n\n"
                    
                    message += "<b>🚀 Топ рост:</b>\n"
                    for i, t in enumerate(gainers[:5], 1):
                        sym = t['symbol'].replace('USDT', '')
                        pct = float(t.get('priceChangePercent', 0))
                        message += f"{i}. {sym}: +{pct:.2f}%\n"
                    
                    message += "\n<b>🔻 Топ падение:</b>\n"
                    for i, t in enumerate(losers[:5], 1):
                        sym = t['symbol'].replace('USDT', '')
                        pct = float(t.get('priceChangePercent', 0))
                        message += f"{i}. {sym}: {pct:.2f}%\n"
                    
                    await self.telegram.send_alert("Рыночная сводка", message)
                
                await asyncio.sleep(300)  # Обновляем каждые 5 минут
                
            except Exception as e:
                logger.error(f"Error in top movers loop: {e}")
                await asyncio.sleep(60)
    
    async def _alert_loop(self):
        """Цикл проверки алертов"""
        
        while self.running:
            try:
                # Проверяем открытые позиции на достижение целей
                for symbol, position in self.portfolio_manager.portfolio.positions.items():
                    current_price = position.current_price
                    
                    # Проверка тейк-профитов
                    for i, (tp_price, tp_pct) in enumerate(position.take_profits, 1):
                        if current_price >= tp_price:
                            message = f"""
🎯 <b>ТЕЙК-ПРОФИТ ДОСТИГНУТ!</b>

<b>💎 Токен:</b> {symbol}
<b>🎯 TP{i}:</b> ${tp_price:.6f}
<b>💰 Текущая цена:</b> ${current_price:.6f}
<b>📈 P&L:</b> +{((current_price/position.entry_price-1)*100):.2f}%

<b>Рекомендация:</b> Закройте {tp_pct*100}% позиции
"""
                            await self.telegram.send_alert("Тейк-профит", message)
                    
                    # Проверка стоп-лосса
                    if current_price <= position.stop_loss:
                        message = f"""
🛑 <b>СТОП-ЛОСС СРАБОТАЛ!</b>

<b>💎 Токен:</b> {symbol}
<b>🛑 SL:</b> ${position.stop_loss:.6f}
<b>💰 Текущая цена:</b> ${current_price:.6f}
<b>📉 P&L:</b> {((current_price/position.entry_price-1)*100):.2f}%

<b>Рекомендация:</b> Закройте позицию немедленно!
"""
                        await self.telegram.send_alert("Стоп-лосс", message)
                
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"Error in alert loop: {e}")
                await asyncio.sleep(30)
    
    def stop(self):
        """Остановить бота"""
        self.running = False
        logger.info("🛑 Бот остановлен")

# ═══════════════════════════════════════════════════════════════════════════════
# ЗАПУСК
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    """Главная функция"""
    bot = CryptoTradingBot()
    
    try:
        await bot.start()
    except KeyboardInterrupt:
        logger.info("Получен сигнал остановки...")
        bot.stop()
    except Exception as e:
        logger.error(f"Critical error: {e}")
        bot.stop()

if __name__ == "__main__":
    print("""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    🤖 ULTIMATE CRYPTO TRADING BOT 🤖                          ║
║                                                                               ║
║  🚀 Запускаем умного торгового бота...                                       ║
║                                                                               ║
║  Возможности:                                                                 ║
║  • Мониторинг 100+ криптовалют в реальном времени                            ║
║  • Технический анализ (RSI, MACD, Bollinger Bands, EMA)                     ║
║  • Проверка токенов на скам (Honeypot, Rug Pull)                            ║
║  • Сигналы на покупку/продажу с уровнями входа/выхода                       ║
║  • Risk Management (Stop-Loss, Take-Profit)                                 ║
║  • Управление портфелем и подсчет P&L                                       ║
║  • Telegram уведомления                                                      ║
║                                                                               ║
║  ⚠️ ВНИМАНИЕ: Это образовательный скрипт. Торговля криптовалютами           ║
║  связана с высокими рисками. Используйте на свой страх и риск!              ║
╚═══════════════════════════════════════════════════════════════════════════════╝
""")
    
    # Проверяем зависимости
    try:
        import pandas
        import numpy
        import telegram
        print("✅ Все зависимости установлены")
    except ImportError as e:
        print(f"❌ Отсутствует зависимость: {e}")
        print("Установите зависимости: pip install -r requirements.txt")
        exit(1)
    
    # Запускаем
    asyncio.run(main())
