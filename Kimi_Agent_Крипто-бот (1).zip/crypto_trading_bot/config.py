#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                         ⚙️ CONFIGURATION FILE ⚙️                              ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

import os
from dataclasses import dataclass, field
from typing import List, Dict

@dataclass
class TradingConfig:
    """Конфигурация торговли"""
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TELEGRAM НАСТРОЙКИ
    # ═══════════════════════════════════════════════════════════════════════════
    TG_TOKEN: str = "7813361546:AAGnQ49TEIoOCgBfrOFRXbB27PgMr56_nec"
    CHAT_ID: str = "-1003689936622"
    
    # ═══════════════════════════════════════════════════════════════════════════
    # API КЛЮЧИ (добавьте свои для реальной торговли)
    # ═══════════════════════════════════════════════════════════════════════════
    BINANCE_API_KEY: str = ""
    BINANCE_SECRET: str = ""
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ПАРАМЕТРЫ СКАНИРОВАНИЯ
    # ═══════════════════════════════════════════════════════════════════════════
    SCAN_INTERVAL: int = 30  # Секунды между сканированиями
    ALERT_COOLDOWN: int = 300  # Кулдаун для повторных алертов (сек)
    
    # Минимальные фильтры
    MIN_VOLUME_24H: float = 100000  # Минимальный объем 24ч ($)
    MIN_LIQUIDITY: float = 50000  # Минимальная ликвидность ($)
    MAX_SLIPPAGE: float = 5  # Максимальный проскальзывание (%)
    
    # Таймфреймы для анализа
    TIMEFRAMES: List[str] = field(default_factory=lambda: ['1m', '5m', '15m', '1h', '4h', '1d'])
    
    # ═══════════════════════════════════════════════════════════════════════════
    # RISK MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    MAX_POSITION_SIZE: float = 100  # Макс позиция ($)
    MAX_OPEN_POSITIONS: int = 5  # Максимум открытых позиций
    
    # Стоп-лоссы и тейк-профиты
    STOP_LOSS: float = 5  # Стоп-лосс (%)
    TRAILING_STOP: float = 3  # Трейлинг-стоп (%)
    
    TAKE_PROFIT_1: float = 10  # Первый тейк-профит (%)
    TAKE_PROFIT_2: float = 20  # Второй тейк-профит (%)
    TAKE_PROFIT_3: float = 50  # Третий тейк-профит (%)
    
    # Распределение позиции по тейк-профитам
    TP1_POSITION_PCT: float = 0.30  # 30% на TP1
    TP2_POSITION_PCT: float = 0.30  # 30% на TP2
    TP3_POSITION_PCT: float = 0.40  # 40% на TP3
    
    # Risk/Reward минимум
    MIN_RISK_REWARD: float = 1.5  # Минимальное соотношение риск/прибыль
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ТЕХНИЧЕСКИЙ АНАЛИЗ
    # ═══════════════════════════════════════════════════════════════════════════
    
    # RSI
    RSI_PERIOD: int = 14
    RSI_OVERBOUGHT: float = 70
    RSI_OVERSOLD: float = 30
    
    # MACD
    MACD_FAST: int = 12
    MACD_SLOW: int = 26
    MACD_SIGNAL: int = 9
    
    # Bollinger Bands
    BB_PERIOD: int = 20
    BB_STD_DEV: float = 2.0
    
    # EMA
    EMA_SHORT: int = 20
    EMA_MEDIUM: int = 50
    EMA_LONG: int = 200
    
    # Объем
    VOLUME_SMA_PERIOD: int = 20
    VOLUME_SPIKE_THRESHOLD: float = 2.0  # Объем в 2 раза выше среднего
    
    # ═══════════════════════════════════════════════════════════════════════════
    # БЕЗОПАСНОСТЬ (ПРОВЕРКА НА СКАМ)
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Максимальные налоги
    MAX_BUY_TAX: float = 5  # Максимальный налог на покупку (%)
    MAX_SELL_TAX: float = 10  # Максимальный налог на продажу (%)
    
    # Минимальный safety score
    MIN_SAFETY_SCORE: int = 70  # 0-100
    
    # Требования к ликвидности
    MIN_LIQUIDITY_LOCK_DAYS: int = 30
    
    # ═══════════════════════════════════════════════════════════════════════════
    # СИГНАЛЬНАЯ СИСТЕМА
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Минимальная уверенность для сигнала
    MIN_CONFIDENCE_BUY: int = 60
    MIN_CONFIDENCE_STRONG_BUY: int = 75
    
    # Веса индикаторов
    WEIGHT_RSI: float = 15
    WEIGHT_MACD: float = 20
    WEIGHT_TREND: float = 25
    WEIGHT_VOLUME: float = 15
    WEIGHT_BB: float = 10
    WEIGHT_EMA_CROSS: float = 15
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ПОРТФЕЛЬ
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Начальный баланс (для симуляции)
    INITIAL_BALANCE: float = 1000
    
    # Максимальный % портфеля в одной сделке
    MAX_POSITION_PORTFOLIO_PCT: float = 20
    
    # ═══════════════════════════════════════════════════════════════════════════
    # УВЕДОМЛЕНИЯ
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Интервалы уведомлений
    PORTFOLIO_UPDATE_INTERVAL: int = 900  # 15 минут
    MARKET_SUMMARY_INTERVAL: int = 3600  # 1 час
    
    # Включить/выключить уведомления
    NOTIFY_SIGNALS: bool = True
    NOTIFY_PORTFOLIO: bool = True
    NOTIFY_ALERTS: bool = True
    NOTIFY_MARKET_SUMMARY: bool = True
    
    # ═══════════════════════════════════════════════════════════════════════════
    # РЕЖИМ РАБОТЫ
    # ═══════════════════════════════════════════════════════════════════════════
    
    # Режим работы: "PAPER" (тестовый), "LIVE" (реальная торговля)
    TRADING_MODE: str = "PAPER"
    
    # Включить симуляцию
    SIMULATE_TRADES: bool = True
    
    # Логирование
    LOG_LEVEL: str = "INFO"
    LOG_TO_FILE: bool = True


# Глобальный экземпляр конфигурации
config = TradingConfig()


def load_from_env():
    """Загрузить конфигурацию из переменных окружения"""
    
    config.TG_TOKEN = os.getenv('TG_TOKEN', config.TG_TOKEN)
    config.CHAT_ID = os.getenv('CHAT_ID', config.CHAT_ID)
    config.BINANCE_API_KEY = os.getenv('BINANCE_API_KEY', config.BINANCE_API_KEY)
    config.BINANCE_SECRET = os.getenv('BINANCE_SECRET', config.BINANCE_SECRET)
    
    # Числовые параметры
    if os.getenv('SCAN_INTERVAL'):
        config.SCAN_INTERVAL = int(os.getenv('SCAN_INTERVAL'))
    if os.getenv('STOP_LOSS'):
        config.STOP_LOSS = float(os.getenv('STOP_LOSS'))
    if os.getenv('MAX_POSITION_SIZE'):
        config.MAX_POSITION_SIZE = float(os.getenv('MAX_POSITION_SIZE'))
    
    # Режим торговли
    config.TRADING_MODE = os.getenv('TRADING_MODE', config.TRADING_MODE)
    config.SIMULATE_TRADES = os.getenv('SIMULATE_TRADES', 'True').lower() == 'true'


def update_config(**kwargs):
    """Обновить конфигурацию"""
    for key, value in kwargs.items():
        if hasattr(config, key):
            setattr(config, key, value)
            print(f"✅ Обновлено: {key} = {value}")
        else:
            print(f"❌ Неизвестный параметр: {key}")


def print_config():
    """Вывести текущую конфигурацию"""
    print("\n" + "=" * 60)
    print("⚙️ ТЕКУЩАЯ КОНФИГУРАЦИЯ")
    print("=" * 60)
    
    for key, value in vars(config).items():
        # Скрываем чувствительные данные
        if 'TOKEN' in key or 'SECRET' in key or 'KEY' in key:
            if value:
                value = value[:10] + "..." + value[-5:] if len(value) > 15 else "***"
        print(f"  {key}: {value}")
    
    print("=" * 60 + "\n")


# Загружаем из окружения при импорте
load_from_env()

if __name__ == "__main__":
    print_config()
