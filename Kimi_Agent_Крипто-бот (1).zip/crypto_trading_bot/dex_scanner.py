#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                         🔍 DEX SCANNER MODULE 🔍                              ║
║                                                                               ║
║  Модуль для сканирования DEX токенов и новых листингов                       ║
║  • Отслеживание новых пар на Uniswap, PancakeSwap                            ║
║  • Анализ ликвидности и объемов                                              ║
║  • Обнаружение ранних трендов                                                ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

import requests
import json
import time
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)

@dataclass
class DexPair:
    """DEX пара"""
    chain: str
    dex: str
    pair_address: str
    token0: str
    token1: str
    token0_symbol: str
    token1_symbol: str
    token0_address: str
    token1_address: str
    price_usd: float = 0
    price_change_1h: float = 0
    price_change_24h: float = 0
    volume_24h: float = 0
    liquidity_usd: float = 0
    tx_count_24h: int = 0
    buyers_24h: int = 0
    sellers_24h: int = 0
    created_at: datetime = None
    
    @property
    def buy_sell_ratio(self) -> float:
        if self.sellers_24h == 0:
            return float('inf')
        return self.buyers_24h / self.sellers_24h
    
    @property
    def is_new(self) -> bool:
        if not self.created_at:
            return False
        return (datetime.now() - self.created_at).hours < 24

class DexScreenerScanner:
    """Сканер DEX через DexScreener API"""
    
    BASE_URL = "https://api.dexscreener.com"
    
    def __init__(self):
        self.session = requests.Session()
        self.known_pairs = set()
        self.new_pairs_queue = []
        
    def get_latest_token_profiles(self) -> List[Dict]:
        """Получить последние профили токенов"""
        try:
            response = self.session.get(f"{self.BASE_URL}/token-profiles/latest/v1")
            return response.json()
        except Exception as e:
            logger.error(f"Error getting token profiles: {e}")
            return []
    
    def get_latest_boosted_tokens(self) -> List[Dict]:
        """Получить продвигаемые токены"""
        try:
            response = self.session.get(f"{self.BASE_URL}/token-boosts/latest/v1")
            return response.json()
        except Exception as e:
            logger.error(f"Error getting boosted tokens: {e}")
            return []
    
    def get_top_boosted_tokens(self) -> List[Dict]:
        """Получить топ продвигаемых токенов"""
        try:
            response = self.session.get(f"{self.BASE_URL}/token-boosts/top/v1")
            return response.json()
        except Exception as e:
            logger.error(f"Error getting top boosted tokens: {e}")
            return []
    
    def search_pairs(self, query: str) -> List[DexPair]:
        """Поиск пар"""
        try:
            response = self.session.get(
                f"{self.BASE_URL}/latest/dex/search",
                params={"q": query}
            )
            data = response.json()
            pairs = []
            
            for p in data.get("pairs", []):
                pair = self._parse_pair(p)
                if pair:
                    pairs.append(pair)
            
            return pairs
        except Exception as e:
            logger.error(f"Error searching pairs: {e}")
            return []
    
    def get_token_pairs(self, chain: str, token_address: str) -> List[DexPair]:
        """Получить все пары для токена"""
        try:
            url = f"{self.BASE_URL}/latest/dex/tokens/{token_address}"
            response = self.session.get(url)
            data = response.json()
            pairs = []
            
            for p in data.get("pairs", []):
                pair = self._parse_pair(p)
                if pair:
                    pairs.append(pair)
            
            return pairs
        except Exception as e:
            logger.error(f"Error getting token pairs: {e}")
            return []
    
    def get_pair_info(self, chain: str, pair_address: str) -> Optional[DexPair]:
        """Получить информацию о паре"""
        try:
            url = f"{self.BASE_URL}/latest/dex/pairs/{chain}/{pair_address}"
            response = self.session.get(url)
            data = response.json()
            
            pairs = data.get("pairs", [])
            if pairs:
                return self._parse_pair(pairs[0])
            return None
        except Exception as e:
            logger.error(f"Error getting pair info: {e}")
            return None
    
    def _parse_pair(self, data: Dict) -> Optional[DexPair]:
        """Парсить данные пары"""
        try:
            volume = data.get("volume", {})
            price_change = data.get("priceChange", {})
            liquidity = data.get("liquidity", {})
            txns = data.get("txns", {}).get("h24", {})
            
            token0 = data.get("baseToken", {})
            token1 = data.get("quoteToken", {})
            
            return DexPair(
                chain=data.get("chainId", "unknown"),
                dex=data.get("dexId", "unknown"),
                pair_address=data.get("pairAddress", ""),
                token0=token0.get("name", ""),
                token1=token1.get("name", ""),
                token0_symbol=token0.get("symbol", ""),
                token1_symbol=token1.get("symbol", ""),
                token0_address=token0.get("address", ""),
                token1_address=token1.get("address", ""),
                price_usd=float(data.get("priceUsd", 0) or 0),
                price_change_1h=float(price_change.get("h1", 0) or 0),
                price_change_24h=float(price_change.get("h24", 0) or 0),
                volume_24h=float(volume.get("h24", 0) or 0),
                liquidity_usd=float(liquidity.get("usd", 0) or 0),
                tx_count_24h=int(txns.get("buys", 0)) + int(txns.get("sells", 0)),
                buyers_24h=int(txns.get("buys", 0)),
                sellers_24h=int(txns.get("sells", 0))
            )
        except Exception as e:
            logger.error(f"Error parsing pair: {e}")
            return None
    
    def scan_for_gems(self, min_volume: float = 10000, 
                     min_liquidity: float = 50000,
                     max_price_change: float = 100) -> List[DexPair]:
        """Сканировать на потенциальные gems"""
        
        gems = []
        
        # Популярные поисковые запросы для поиска новых токенов
        search_queries = [
            "AI", "MEME", "DOGE", "PEPE", "SHIB",
            "LAUNCH", "NEW", "GEM", "MOON", "1000X"
        ]
        
        for query in search_queries:
            try:
                pairs = self.search_pairs(query)
                
                for pair in pairs:
                    # Фильтры
                    if pair.volume_24h < min_volume:
                        continue
                    if pair.liquidity_usd < min_liquidity:
                        continue
                    if abs(pair.price_change_24h) > max_price_change:
                        continue
                    
                    # Дополнительные критерии для gems
                    score = 0
                    
                    # Высокий объем относительно ликвидности
                    if pair.volume_24h > pair.liquidity_usd * 0.5:
                        score += 10
                    
                    # Положительное изменение цены
                    if pair.price_change_24h > 10:
                        score += 5
                    
                    # Больше покупателей чем продавцов
                    if pair.buy_sell_ratio > 1.5:
                        score += 10
                    
                    # Высокая активность транзакций
                    if pair.tx_count_24h > 1000:
                        score += 5
                    
                    if score >= 15:
                        gems.append((pair, score))
                
                time.sleep(0.5)  # Rate limiting
                
            except Exception as e:
                logger.error(f"Error scanning for gems: {e}")
        
        # Сортируем по скору
        gems.sort(key=lambda x: x[1], reverse=True)
        return [g[0] for g in gems[:20]]

class NewPairsMonitor:
    """Монитор новых пар"""
    
    def __init__(self, dex_scanner: DexScreenerScanner):
        self.scanner = dex_scanner
        self.known_pairs = set()
        self.new_pairs_callbacks = []
        
    async def start_monitoring(self, interval: int = 60):
        """Начать мониторинг новых пар"""
        
        # Загружаем существующие пары
        await self._load_existing_pairs()
        
        while True:
            try:
                await self._check_new_pairs()
                await asyncio.sleep(interval)
            except Exception as e:
                logger.error(f"Error in new pairs monitoring: {e}")
                await asyncio.sleep(10)
    
    async def _load_existing_pairs(self):
        """Загрузить существующие пары"""
        # Получаем популярные пары
        popular_tokens = ["WETH", "WBTC", "USDC", "USDT"]
        
        for token in popular_tokens:
            pairs = self.scanner.search_pairs(token)
            for pair in pairs:
                self.known_pairs.add(pair.pair_address)
            
            await asyncio.sleep(0.5)
        
        logger.info(f"Loaded {len(self.known_pairs)} existing pairs")
    
    async def _check_new_pairs(self):
        """Проверить новые пары"""
        
        # Получаем последние профили токенов
        profiles = self.scanner.get_latest_token_profiles()
        
        for profile in profiles:
            try:
                token_address = profile.get("tokenAddress", "")
                chain = profile.get("chainId", "")
                
                if not token_address:
                    continue
                
                # Получаем пары для токена
                pairs = self.scanner.get_token_pairs(chain, token_address)
                
                for pair in pairs:
                    if pair.pair_address not in self.known_pairs:
                        # Новая пара!
                        self.known_pairs.add(pair.pair_address)
                        
                        # Вызываем колбэки
                        for callback in self.new_pairs_callbacks:
                            try:
                                await callback(pair)
                            except Exception as e:
                                logger.error(f"Error in new pair callback: {e}")
                
                await asyncio.sleep(0.3)
                
            except Exception as e:
                logger.error(f"Error checking new pair: {e}")
    
    def on_new_pair(self, callback):
        """Добавить колбэк на новую пару"""
        self.new_pairs_callbacks.append(callback)

class LiquidityMonitor:
    """Монитор ликвидности"""
    
    def __init__(self, dex_scanner: DexScreenerScanner):
        self.scanner = dex_scanner
        self.liquidity_history = defaultdict(list)
        self.alerts_callbacks = []
        
    def track_pair(self, pair_address: str, chain: str):
        """Начать отслеживание пары"""
        # Добавляем в отслеживание
        pass
    
    async def monitor_loop(self, interval: int = 300):
        """Цикл мониторинга"""
        
        while True:
            try:
                for pair_address in list(self.liquidity_history.keys()):
                    # Получаем текущую информацию
                    # Проверяем изменения
                    pass
                
                await asyncio.sleep(interval)
                
            except Exception as e:
                logger.error(f"Error in liquidity monitoring: {e}")
                await asyncio.sleep(10)
    
    def check_rug_pull_risk(self, pair: DexPair) -> Dict:
        """Проверить риск rug pull"""
        
        risk_factors = []
        risk_score = 0
        
        # Низкая ликвидность
        if pair.liquidity_usd < 10000:
            risk_score += 30
            risk_factors.append("Очень низкая ликвидность")
        elif pair.liquidity_usd < 50000:
            risk_score += 15
            risk_factors.append("Низкая ликвидность")
        
        # Высокие налоги (предполагаемые)
        if pair.price_change_24h > 50 and pair.volume_24h < pair.liquidity_usd:
            risk_score += 20
            risk_factors.append("Подозрительный рост цены при низком объеме")
        
        # Мало транзакций
        if pair.tx_count_24h < 50:
            risk_score += 10
            risk_factors.append("Низкая активность транзакций")
        
        # Неравное соотношение покупок/продаж
        if pair.buy_sell_ratio > 3 or pair.buy_sell_ratio < 0.33:
            risk_score += 10
            risk_factors.append("Подозрительное соотношение покупок/продаж")
        
        return {
            "risk_score": min(risk_score, 100),
            "risk_level": "HIGH" if risk_score > 50 else "MEDIUM" if risk_score > 25 else "LOW",
            "risk_factors": risk_factors,
            "is_suspicious": risk_score > 40
        }

# Пример использования
async def test_dex_scanner():
    """Тест сканера"""
    scanner = DexScreenerScanner()
    
    # Поиск токенов AI
    print("🔍 Поиск AI токенов...")
    ai_pairs = scanner.search_pairs("AI")
    
    for pair in ai_pairs[:5]:
        print(f"\n💎 {pair.token0_symbol}/{pair.token1_symbol}")
        print(f"   Цена: ${pair.price_usd:.6f}")
        print(f"   Изменение 24ч: {pair.price_change_24h:+.2f}%")
        print(f"   Объем 24ч: ${pair.volume_24h:,.0f}")
        print(f"   Ликвидность: ${pair.liquidity_usd:,.0f}")
        print(f"   Покупок/Продаж: {pair.buyers_24h}/{pair.sellers_24h}")

if __name__ == "__main__":
    asyncio.run(test_dex_scanner())
