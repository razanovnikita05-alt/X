#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║              🤖 ULTIMATE CRYPTO TRADING BOT v2.0 - PRO 🤖                     ║
║                                                                               ║
║  Улучшенный бот с админ-панелью, rate limiting и умной фильтрацией           ║
║  • Админ-панель в Telegram с паролем                                         ║
║  • Rate limiting - защита от flood control                                   ║
║  • Улучшенная фильтрация сигналов (меньше спама)                             ║
║  • Вечный мониторинг с автопереподключением                                  ║
║  • Фокус на качественных трейдинг сигналах                                   ║
╚═══════════════════════════════════════════════════════════════════════════════╝
"""

import requests
import json
import time
import asyncio
import aiohttp
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
import logging
from collections import defaultdict, deque
import threading
from decimal import Decimal
import hashlib
import hmac
import sys
import os
import re

# Исправление кодировки для Windows
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

# Telegram
from telegram import Bot, Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters

# Настройка логирования с UTF-8
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('crypto_bot.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# КОНФИГУРАЦИЯ
# ═══════════════════════════════════════════════════════════════════════════════

class Config:
    """Конфигурация бота"""
    # Telegram
    TG_TOKEN = "7813361546:AAGnQ49TEIoOCgBfrOFRXbB27PgMr56_nec"
    CHAT_ID = "-1003689936622"
    ADMIN_PASSWORD = "admin123"  # Пароль для админ-панели
    
    # Настройки rate limiting
    TG_MSG_DELAY = 1.5  # Минимальная задержка между сообщениями (сек)
    TG_BURST_LIMIT = 20  # Макс сообщений в минуту
    
    # API Keys
    BINANCE_API_KEY = ""
    BINANCE_SECRET = ""
    
    # Параметры торговли - УЛУЧШЕННЫЕ для меньшего спама
    MIN_VOLUME_24H = 500000  # Увеличено: Минимальный объем 24ч ($)
    MAX_SLIPPAGE = 3
    MIN_LIQUIDITY = 100000  # Увеличено
    
    # Risk Management
    MAX_POSITION_SIZE = 100
    STOP_LOSS = 5
    TAKE_PROFIT_1 = 10
    TAKE_PROFIT_2 = 25
    TAKE_PROFIT_3 = 50
    
    # УЛУЧШЕННЫЕ настройки сигналов - меньше спама
    MIN_CONFIDENCE = 75  # Увеличено: минимальная уверенность
    SIGNAL_COOLDOWN_HOURS = 6  # Увеличено: кулдаун между сигналами на один токен
    MAX_SIGNALS_PER_SCAN = 3  # Макс сигналов за одно сканирование
    
    # Таймфреймы
    TIMEFRAMES = ['15m', '1h', '4h']
    
    # Интервалы
    SCAN_INTERVAL = 60  # Увеличено: секунды между сканированиями
    TOP_TOKENS_COUNT = 50  # Сканировать только топ-N токенов
    
    # Приоритетные токены (всегда мониторим)
    PRIORITY_TOKENS = [
        'BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'ADAUSDT',
        'XRPUSDT', 'DOTUSDT', 'DOGEUSDT', 'AVAXUSDT', 'LINKUSDT'
    ]

# ═══════════════════════════════════════════════════════════════════════════════
# DATA CLASSES
# ═══════════════════════════════════════════════════════════════════════════════

class SignalType(Enum):
    STRONG_BUY = "[STRONG BUY] СИЛЬНАЯ ПОКУПКА"
    BUY = "[BUY] ПОКУПКА"
    HOLD = "[HOLD] ДЕРЖАТЬ"
    SELL = "[SELL] ПРОДАЖА"
    STRONG_SELL = "[STRONG SELL] СИЛЬНАЯ ПРОДАЖА"
    WAIT = "[WAIT] ОЖИДАТЬ"

class RiskLevel(Enum):
    LOW = "[LOW] НИЗКИЙ"
    MEDIUM = "[MEDIUM] СРЕДНИЙ"
    HIGH = "[HIGH] ВЫСОКИЙ"
    EXTREME = "[EXTREME] ЭКСТРЕМАЛЬНЫЙ"

@dataclass
class TokenData:
    """Данные токена"""
    symbol: str
    name: str
    price: float
    price_change_1h: float = 0
    price_change_24h: float = 0
    volume_24h: float = 0
    market_cap: float = 0
    liquidity: float = 0
    rank: int = 999  # Ранг по объему

@dataclass
class TechnicalIndicators:
    """Технические индикаторы"""
    rsi: float = 50
    rsi_signal: str = "NEUTRAL"
    macd: float = 0
    macd_signal: float = 0
    macd_histogram: float = 0
    bb_upper: float = 0
    bb_middle: float = 0
    bb_lower: float = 0
    ema_20: float = 0
    ema_50: float = 0
    ema_200: float = 0
    trend: str = "NEUTRAL"
    volume_ratio: float = 1
    support: float = 0
    resistance: float = 0
    
    # Дополнительные
    adx: float = 0  # Сила тренда
    atr: float = 0  # Волатильность

@dataclass
class ScamCheck:
    """Результат проверки на скам"""
    score: int = 100
    warnings: List[str] = field(default_factory=list)
    
    @property
    def is_safe(self) -> bool:
        return self.score >= 70

@dataclass
class TradingSignal:
    """Торговый сигнал"""
    symbol: str
    signal_type: SignalType
    entry_price: float
    target_prices: List[float]
    stop_loss: float
    risk_level: RiskLevel
    confidence: int
    timeframe: str
    indicators: TechnicalIndicators
    token_data: TokenData
    reasoning: List[str]
    timestamp: datetime = field(default_factory=datetime.now)
    
    @property
    def risk_reward_ratio(self) -> float:
        if self.entry_price == 0 or self.stop_loss == 0:
            return 0
        risk = abs(self.entry_price - self.stop_loss)
        reward = abs(self.target_prices[0] - self.entry_price) if self.target_prices else 0
        return reward / risk if risk > 0 else 0

@dataclass
class Position:
    """Открытая позиция"""
    symbol: str
    entry_price: float
    quantity: float
    entry_time: datetime
    stop_loss: float
    take_profits: List[Tuple[float, float]]
    invested: float
    current_price: float = 0
    unrealized_pnl: float = 0
    realized_pnl: float = 0
    status: str = "OPEN"

@dataclass
class Portfolio:
    """Портфель"""
    total_balance: float = 0
    available_usdt: float = 1000
    positions: Dict[str, Position] = field(default_factory=dict)
    closed_positions: List[Position] = field(default_factory=list)
    total_pnl: float = 0
    win_rate: float = 0
    total_trades: int = 0
    winning_trades: int = 0

# ═══════════════════════════════════════════════════════════════════════════════
# RATE LIMITER
# ═══════════════════════════════════════════════════════════════════════════════

class RateLimiter:
    """Rate limiter для Telegram API"""
    
    def __init__(self, max_requests: int = 20, window_seconds: int = 60):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests = deque()
        self.lock = asyncio.Lock()
    
    async def acquire(self):
        """Получить разрешение на запрос"""
        async with self.lock:
            now = time.time()
            
            # Удаляем старые запросы
            while self.requests and self.requests[0] < now - self.window_seconds:
                self.requests.popleft()
            
            # Если достигли лимита - ждем
            if len(self.requests) >= self.max_requests:
                sleep_time = self.requests[0] + self.window_seconds - now
                if sleep_time > 0:
                    logger.info(f"Rate limit: ждем {sleep_time:.1f} сек")
                    await asyncio.sleep(sleep_time)
                    return await self.acquire()
            
            self.requests.append(now)

# ═══════════════════════════════════════════════════════════════════════════════
# TELEGRAM NOTIFIER с Rate Limiting
# ═══════════════════════════════════════════════════════════════════════════════

class TelegramNotifier:
    """Уведомления в Telegram с rate limiting"""
    
    def __init__(self, token: str, chat_id: str):
        self.token = token
        self.chat_id = chat_id
        self.bot = Bot(token=token)
        self.rate_limiter = RateLimiter(max_requests=20, window_seconds=60)
        self.message_queue = asyncio.Queue()
        self.running = False
        self.last_message_time = 0
        self.min_delay = Config.TG_MSG_DELAY
        
        # Статистика
        self.messages_sent = 0
        self.messages_dropped = 0
    
    async def start(self):
        """Запустить обработчик очереди"""
        self.running = True
        asyncio.create_task(self._process_queue())
    
    async def _process_queue(self):
        """Обработка очереди сообщений с rate limiting"""
        while self.running:
            try:
                message = await asyncio.wait_for(self.message_queue.get(), timeout=1)
                
                # Rate limiting
                await self.rate_limiter.acquire()
                
                # Минимальная задержка между сообщениями
                time_since_last = time.time() - self.last_message_time
                if time_since_last < self.min_delay:
                    await asyncio.sleep(self.min_delay - time_since_last)
                
                success = await self._send_message_safe(message)
                
                if success:
                    self.last_message_time = time.time()
                    self.messages_sent += 1
                else:
                    self.messages_dropped += 1
                
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Error processing queue: {e}")
    
    async def _send_message_safe(self, message: str) -> bool:
        """Безопасная отправка сообщения с retry"""
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                await self.bot.send_message(
                    chat_id=self.chat_id,
                    text=message,
                    parse_mode=ParseMode.HTML,
                    disable_web_page_preview=True
                )
                return True
                
            except Exception as e:
                error_str = str(e).lower()
                
                # Flood control
                if 'flood' in error_str or '429' in error_str:
                    retry_after = 30 if 'retry after' not in error_str else 30
                    logger.warning(f"Flood control, ждем {retry_after} сек")
                    await asyncio.sleep(retry_after)
                    continue
                
                # Другие ошибки
                logger.error(f"Error sending message (attempt {attempt+1}): {e}")
                await asyncio.sleep(2 ** attempt)  # Exponential backoff
        
        return False
    
    async def send_signal(self, signal: TradingSignal):
        """Отправить сигнал (только важные)"""
        
        # Формируем компактное сообщение без эмодзи проблемных
        emoji = "[BUY]" if "BUY" in signal.signal_type.value else "[SELL]"
        
        message = f"""<b>{emoji} {signal.signal_type.value}</b>

<b>Токен:</b> <code>{signal.symbol}</code>
<b>Уверенность:</b> {signal.confidence}%
<b>Риск:</b> {signal.risk_level.value}

<b>Цена входа:</b> <code>${signal.entry_price:.8f}</code>
<b>Стоп-лосс:</b> <code>${signal.stop_loss:.8f}</code> ({((signal.stop_loss/signal.entry_price-1)*100):.2f}%)

<b>Цели:</b>
TP1: <code>${signal.target_prices[0]:.8f}</code> (+{((signal.target_prices[0]/signal.entry_price-1)*100):.2f}%)
TP2: <code>${signal.target_prices[1]:.8f}</code> (+{((signal.target_prices[1]/signal.entry_price-1)*100):.2f}%)
TP3: <code>${signal.target_prices[2]:.8f}</code> (+{((signal.target_prices[2]/signal.entry_price-1)*100):.2f}%)

<b>Risk/Reward:</b> 1:{signal.risk_reward_ratio:.2f}

<b>Индикаторы:</b>
RSI: {signal.indicators.rsi:.1f} | MACD: {signal.indicators.macd:.4f}
Тренд: {signal.indicators.trend} | Объем: x{signal.indicators.volume_ratio:.1f}

<b>Обоснование:</b>
"""
        for reason in signal.reasoning[:3]:  # Только топ-3 причины
            message += f"• {reason}\n"
        
        message += f"\n<i>{signal.timestamp.strftime('%Y-%m-%d %H:%M')}</i>"
        
        await self.message_queue.put(message)
    
    async def send_portfolio_update(self, portfolio: Portfolio):
        """Отправить обновление портфеля (компактное)"""
        
        message = f"""<b>[PORTFOLIO] ПОРТФЕЛЬ</b>

Баланс: ${portfolio.total_balance:.2f}
Доступно: ${portfolio.available_usdt:.2f}
P&L: ${portfolio.total_pnl:+.2f}
Win Rate: {portfolio.win_rate:.1f}% ({portfolio.winning_trades}/{portfolio.total_trades})

Открытых позиций: {len(portfolio.positions)}
"""
        
        if portfolio.positions:
            message += "\n<b>Позиции:</b>\n"
            for symbol, pos in list(portfolio.positions.items())[:5]:  # Топ 5
                pnl_pct = ((pos.current_price / pos.entry_price - 1) * 100) if pos.entry_price > 0 else 0
                message += f"{symbol}: {pnl_pct:+.2f}%\n"
        
        await self.message_queue.put(message)
    
    async def send_alert(self, title: str, message: str):
        """Отправить алерт"""
        full_message = f"<b>[ALERT] {title}</b>\n\n{message}"
        await self.message_queue.put(full_message)
    
    async def send_startup_message(self):
        """Отправить сообщение о запуске"""
        message = """<b>[STARTED] CRYPTO BOT ЗАПУЩЕН</b>

Возможности:
• Мониторинг топ-50 токенов
• Технический анализ
• Умная фильтрация сигналов
• Risk Management

Команды:
/admin - Админ панель
/portfolio - Портфель
/stats - Статистика
/settings - Настройки

<i>Ожидайте сигналов...</i>
"""
        await self.message_queue.put(message)
    
    def get_stats(self) -> Dict:
        """Получить статистику"""
        return {
            'sent': self.messages_sent,
            'dropped': self.messages_dropped,
            'queue_size': self.message_queue.qsize()
        }

# ═══════════════════════════════════════════════════════════════════════════════
# BINANCE CLIENT
# ═══════════════════════════════════════════════════════════════════════════════

class BinanceClient:
    """Клиент для Binance API с retry логикой"""
    BASE_URL = "https://api.binance.com"
    
    def __init__(self):
        self.session = requests.Session()
        self.last_prices = {}
        self.request_count = 0
        self.last_request_time = 0
        self.min_request_interval = 0.05  # 50ms между запросами
    
    def _rate_limit(self):
        """Применить rate limiting"""
        elapsed = time.time() - self.last_request_time
        if elapsed < self.min_request_interval:
            time.sleep(self.min_request_interval - elapsed)
        self.last_request_time = time.time()
    
    def get_all_tickers(self) -> List[Dict]:
        """Получить все тикеры"""
        try:
            self._rate_limit()
            response = self.session.get(f"{self.BASE_URL}/api/v3/ticker/24hr", timeout=10)
            self.request_count += 1
            return response.json()
        except Exception as e:
            logger.error(f"Error getting tickers: {e}")
            return []
    
    def get_klines(self, symbol: str, interval: str = "1h", limit: int = 100) -> List[List]:
        """Получить свечи"""
        try:
            self._rate_limit()
            params = {"symbol": symbol, "interval": interval, "limit": limit}
            response = self.session.get(f"{self.BASE_URL}/api/v3/klines", params=params, timeout=10)
            self.request_count += 1
            return response.json()
        except Exception as e:
            logger.error(f"Error getting klines for {symbol}: {e}")
            return []
    
    def get_ticker_price(self, symbol: str) -> float:
        """Получить текущую цену"""
        try:
            self._rate_limit()
            response = self.session.get(
                f"{self.BASE_URL}/api/v3/ticker/price", 
                params={"symbol": symbol},
                timeout=5
            )
            self.request_count += 1
            data = response.json()
            price = float(data.get("price", 0))
            self.last_prices[symbol] = price
            return price
        except Exception as e:
            logger.error(f"Error getting price for {symbol}: {e}")
            return self.last_prices.get(symbol, 0)

# ═══════════════════════════════════════════════════════════════════════════════
# TECHNICAL ANALYZER
# ═══════════════════════════════════════════════════════════════════════════════

class TechnicalAnalyzer:
    """Технический анализ"""
    
    @staticmethod
    def calculate_rsi(prices: pd.Series, period: int = 14) -> float:
        """Рассчитать RSI"""
        if len(prices) < period:
            return 50
        
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi.iloc[-1] if not pd.isna(rsi.iloc[-1]) else 50
    
    @staticmethod
    def calculate_macd(prices: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[float, float, float]:
        """Рассчитать MACD"""
        if len(prices) < slow:
            return 0, 0, 0
        
        exp1 = prices.ewm(span=fast).mean()
        exp2 = prices.ewm(span=slow).mean()
        macd = exp1 - exp2
        signal_line = macd.ewm(span=signal).mean()
        histogram = macd - signal_line
        
        return macd.iloc[-1], signal_line.iloc[-1], histogram.iloc[-1]
    
    @staticmethod
    def calculate_bollinger_bands(prices: pd.Series, period: int = 20, std_dev: int = 2) -> Tuple[float, float, float]:
        """Рассчитать Bollinger Bands"""
        if len(prices) < period:
            return 0, 0, 0
        
        sma = prices.rolling(window=period).mean()
        std = prices.rolling(window=period).std()
        
        upper = sma + (std * std_dev)
        lower = sma - (std * std_dev)
        
        return upper.iloc[-1], sma.iloc[-1], lower.iloc[-1]
    
    @staticmethod
    def calculate_ema(prices: pd.Series, period: int) -> float:
        """Рассчитать EMA"""
        if len(prices) < period:
            return prices.iloc[-1] if len(prices) > 0 else 0
        
        ema = prices.ewm(span=period).mean()
        return ema.iloc[-1]
    
    @staticmethod
    def calculate_atr(df: pd.DataFrame, period: int = 14) -> float:
        """Рассчитать ATR (Average True Range)"""
        if len(df) < period:
            return 0
        
        high = df['high']
        low = df['low']
        close = df['close']
        
        tr1 = high - low
        tr2 = abs(high - close.shift())
        tr3 = abs(low - close.shift())
        
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(window=period).mean()
        
        return atr.iloc[-1] if not pd.isna(atr.iloc[-1]) else 0
    
    @staticmethod
    def calculate_adx(df: pd.DataFrame, period: int = 14) -> float:
        """Рассчитать ADX (сила тренда)"""
        if len(df) < period + 1:
            return 0
        
        high = df['high']
        low = df['low']
        close = df['close']
        
        plus_dm = high.diff()
        minus_dm = -low.diff()
        
        plus_dm = plus_dm.where((plus_dm > minus_dm) & (plus_dm > 0), 0)
        minus_dm = minus_dm.where((minus_dm > plus_dm) & (minus_dm > 0), 0)
        
        tr = pd.concat([
            high - low,
            abs(high - close.shift()),
            abs(low - close.shift())
        ], axis=1).max(axis=1)
        
        atr = tr.rolling(window=period).mean()
        
        plus_di = 100 * plus_dm.rolling(window=period).mean() / atr
        minus_di = 100 * minus_dm.rolling(window=period).mean() / atr
        
        dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
        adx = dx.rolling(window=period).mean()
        
        return adx.iloc[-1] if not pd.isna(adx.iloc[-1]) else 0
    
    def analyze(self, klines: List[List]) -> TechnicalIndicators:
        """Полный технический анализ"""
        if not klines or len(klines) < 50:
            return TechnicalIndicators()
        
        df = pd.DataFrame(klines, columns=[
            'timestamp', 'open', 'high', 'low', 'close', 'volume',
            'close_time', 'quote_volume', 'trades', 'taker_buy_base',
            'taker_buy_quote', 'ignore'
        ])
        
        for col in ['open', 'high', 'low', 'close', 'volume']:
            df[col] = pd.to_numeric(df[col])
        
        prices = df['close']
        volumes = df['volume']
        
        indicators = TechnicalIndicators()
        
        # RSI
        indicators.rsi = self.calculate_rsi(prices)
        
        # MACD
        indicators.macd, indicators.macd_signal, indicators.macd_histogram = \
            self.calculate_macd(prices)
        
        # Bollinger Bands
        indicators.bb_upper, indicators.bb_middle, indicators.bb_lower = \
            self.calculate_bollinger_bands(prices)
        
        # EMA
        indicators.ema_20 = self.calculate_ema(prices, 20)
        indicators.ema_50 = self.calculate_ema(prices, 50)
        indicators.ema_200 = self.calculate_ema(prices, 200)
        
        # Тренд
        if indicators.ema_20 > indicators.ema_50 > indicators.ema_200:
            indicators.trend = "STRONG_UPTREND"
        elif indicators.ema_20 > indicators.ema_50:
            indicators.trend = "UPTREND"
        elif indicators.ema_20 < indicators.ema_50 < indicators.ema_200:
            indicators.trend = "STRONG_DOWNTREND"
        elif indicators.ema_20 < indicators.ema_50:
            indicators.trend = "DOWNTREND"
        else:
            indicators.trend = "SIDEWAYS"
        
        # Объемы
        avg_volume = volumes.rolling(window=20).mean().iloc[-1]
        indicators.volume_ratio = volumes.iloc[-1] / avg_volume if avg_volume > 0 else 1
        
        # Support/Resistance
        indicators.support = prices.rolling(window=20).min().iloc[-1]
        indicators.resistance = prices.rolling(window=20).max().iloc[-1]
        
        # ATR и ADX
        indicators.atr = self.calculate_atr(df)
        indicators.adx = self.calculate_adx(df)
        
        return indicators

# ═══════════════════════════════════════════════════════════════════════════════
# SIGNAL ENGINE - УЛУЧШЕННЫЙ
# ═══════════════════════════════════════════════════════════════════════════════

class SignalEngine:
    """Улучшенный движок генерации сигналов"""
    
    def __init__(self):
        self.analyzer = TechnicalAnalyzer()
        self.last_signals = {}  # Кулдаун для токенов
        self.signals_today = 0
        self.last_reset = datetime.now()
    
    def generate_signal(self, symbol: str, klines: List[List], 
                       token_data: TokenData = None) -> Optional[TradingSignal]:
        """Сгенерировать торговый сигнал с улучшенной фильтрацией"""
        
        # Сброс счетчика раз в день
        if (datetime.now() - self.last_reset).days >= 1:
            self.signals_today = 0
            self.last_reset = datetime.now()
        
        # Проверяем кулдаун для токена
        if symbol in self.last_signals:
            last_time = self.last_signals[symbol]
            hours_since = (datetime.now() - last_time).total_seconds() / 3600
            if hours_since < Config.SIGNAL_COOLDOWN_HOURS:
                return None
        
        # Технический анализ
        indicators = self.analyzer.analyze(klines)
        
        # Определяем тип сигнала
        signal_type, confidence, reasoning = self._evaluate_signal(indicators, token_data)
        
        # СТРОГАЯ ФИЛЬТРАЦИЯ - только сильные сигналы
        if signal_type not in [SignalType.STRONG_BUY, SignalType.STRONG_SELL]:
            return None
        
        # Минимальная уверенность
        if confidence < Config.MIN_CONFIDENCE:
            return None
        
        # Проверка Risk/Reward
        current_price = float(klines[-1][4]) if klines else 0
        entry_price = current_price
        stop_loss = self._calculate_stop_loss(indicators, current_price, signal_type)
        targets = self._calculate_targets(indicators, current_price, signal_type)
        
        risk = abs(entry_price - stop_loss)
        reward = abs(targets[0] - entry_price) if targets else 0
        risk_reward = reward / risk if risk > 0 else 0
        
        # Минимум 1:1.5 Risk/Reward
        if risk_reward < 1.5:
            return None
        
        # Проверка силы тренда (ADX)
        if indicators.adx < 20:  # Слабый тренд
            return None
        
        # Определяем риск
        risk_level = self._calculate_risk_level(indicators)
        
        # Создаем сигнал
        signal = TradingSignal(
            symbol=symbol,
            signal_type=signal_type,
            entry_price=entry_price,
            target_prices=targets,
            stop_loss=stop_loss,
            risk_level=risk_level,
            confidence=confidence,
            timeframe="1h",
            indicators=indicators,
            token_data=token_data or TokenData(symbol=symbol, name=symbol, price=current_price),
            reasoning=reasoning
        )
        
        # Обновляем кулдаун
        self.last_signals[symbol] = datetime.now()
        self.signals_today += 1
        
        return signal
    
    def _evaluate_signal(self, ind: TechnicalIndicators, 
                         token_data: TokenData) -> Tuple[SignalType, int, List[str]]:
        """Оценить и сгенерировать сигнал"""
        
        score = 0
        confidence = 50
        reasons = []
        
        # RSI анализ - более строгий
        if ind.rsi < 25:  # Перепроданность
            score += 3
            confidence += 15
            reasons.append(f"RSI сильно перепродан ({ind.rsi:.1f})")
        elif ind.rsi < 35:
            score += 1
            confidence += 5
            reasons.append(f"RSI перепродан ({ind.rsi:.1f})")
        elif ind.rsi > 75:  # Перекупленность
            score -= 3
            confidence -= 15
            reasons.append(f"RSI сильно перекуплен ({ind.rsi:.1f})")
        elif ind.rsi > 65:
            score -= 1
            confidence -= 5
            reasons.append(f"RSI перекуплен ({ind.rsi:.1f})")
        
        # MACD анализ
        if ind.macd > ind.macd_signal and ind.macd_histogram > 0:
            if ind.macd_histogram > ind.macd_histogram * 0.1:  # Растущая гистограмма
                score += 2
                confidence += 10
                reasons.append("MACD бычий кросс с ростом")
        elif ind.macd < ind.macd_signal and ind.macd_histogram < 0:
            score -= 2
            confidence -= 10
            reasons.append("MACD медвежий кросс")
        
        # Bollinger Bands
        current_price = ind.ema_20
        if current_price < ind.bb_lower * 1.01:
            score += 2
            confidence += 10
            reasons.append("Цена у нижней BB")
        elif current_price > ind.bb_upper * 0.99:
            score -= 2
            confidence -= 10
            reasons.append("Цена у верхней BB")
        
        # Тренд
        if ind.trend == "STRONG_UPTREND":
            score += 2
            confidence += 10
            reasons.append("Сильный восходящий тренд")
        elif ind.trend == "UPTREND":
            score += 1
            confidence += 5
            reasons.append("Восходящий тренд")
        elif ind.trend == "STRONG_DOWNTREND":
            score -= 2
            confidence -= 10
            reasons.append("Сильный нисходящий тренд")
        elif ind.trend == "DOWNTREND":
            score -= 1
            confidence -= 5
            reasons.append("Нисходящий тренд")
        
        # Объем
        if ind.volume_ratio > 2:
            score += 1
            confidence += 5
            reasons.append(f"Высокий объем (x{ind.volume_ratio:.1f})")
        
        # ADX - сила тренда
        if ind.adx > 40:
            confidence += 10
            reasons.append(f"Сильный тренд (ADX: {ind.adx:.1f})")
        
        # Определяем тип сигнала
        if score >= 5 and confidence >= 80:
            return SignalType.STRONG_BUY, min(confidence, 95), reasons
        elif score >= 3 and confidence >= 70:
            return SignalType.BUY, min(confidence, 85), reasons
        elif score <= -5 and confidence <= 20:
            return SignalType.STRONG_SELL, min(100 - confidence, 95), reasons
        elif score <= -3 and confidence <= 30:
            return SignalType.SELL, min(100 - confidence, 85), reasons
        else:
            return SignalType.WAIT, 50, reasons
    
    def _calculate_stop_loss(self, ind: TechnicalIndicators, 
                            entry: float, signal_type: SignalType) -> float:
        """Рассчитать стоп-лосс на основе ATR"""
        
        atr_multiplier = 2
        stop_distance = ind.atr * atr_multiplier
        
        if "BUY" in signal_type.value:
            return max(entry - stop_distance, ind.support * 0.98)
        else:
            return min(entry + stop_distance, ind.resistance * 1.02)
    
    def _calculate_targets(self, ind: TechnicalIndicators, 
                          entry: float, signal_type: SignalType) -> List[float]:
        """Рассчитать цели на основе R/R"""
        
        atr = ind.atr
        
        if "BUY" in signal_type.value:
            tp1 = entry + atr * 3  # 3R
            tp2 = entry + atr * 5  # 5R
            tp3 = entry + atr * 8  # 8R
        else:
            tp1 = entry - atr * 3
            tp2 = entry - atr * 5
            tp3 = entry - atr * 8
        
        return [tp1, tp2, tp3]
    
    def _calculate_risk_level(self, ind: TechnicalIndicators) -> RiskLevel:
        """Рассчитать уровень риска"""
        
        risk_score = 0
        
        # Волатильность
        if ind.atr > 0 and ind.ema_20 > 0:
            atr_pct = ind.atr / ind.ema_20 * 100
            if atr_pct > 5:
                risk_score += 2
            elif atr_pct > 3:
                risk_score += 1
        
        # Тренд
        if ind.trend == "SIDEWAYS":
            risk_score += 1
        
        # RSI экстремум
        if ind.rsi < 15 or ind.rsi > 85:
            risk_score += 1
        
        if risk_score >= 3:
            return RiskLevel.HIGH
        elif risk_score >= 1:
            return RiskLevel.MEDIUM
        else:
            return RiskLevel.LOW

# ═══════════════════════════════════════════════════════════════════════════════
# PORTFOLIO MANAGER
# ═══════════════════════════════════════════════════════════════════════════════

class PortfolioManager:
    """Управление портфелем"""
    
    def __init__(self):
        self.portfolio = Portfolio()
        self.load_portfolio()
    
    def load_portfolio(self):
        """Загрузить портфель из файла"""
        try:
            with open('portfolio.json', 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.portfolio.total_balance = data.get('total_balance', 0)
                self.portfolio.available_usdt = data.get('available_usdt', 1000)
                self.portfolio.total_pnl = data.get('total_pnl', 0)
                self.portfolio.total_trades = data.get('total_trades', 0)
                self.portfolio.winning_trades = data.get('winning_trades', 0)
        except FileNotFoundError:
            self.portfolio.available_usdt = 1000
            self.save_portfolio()
    
    def save_portfolio(self):
        """Сохранить портфель"""
        data = {
            'total_balance': self.portfolio.total_balance,
            'available_usdt': self.portfolio.available_usdt,
            'total_pnl': self.portfolio.total_pnl,
            'total_trades': self.portfolio.total_trades,
            'winning_trades': self.portfolio.winning_trades,
        }
        with open('portfolio.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    
    def update_prices(self, prices: Dict[str, float]):
        """Обновить цены позиций"""
        for symbol, price in prices.items():
            if symbol in self.portfolio.positions:
                pos = self.portfolio.positions[symbol]
                pos.current_price = price
                pos.unrealized_pnl = (price - pos.entry_price) * pos.quantity
    
    def get_summary(self) -> Dict:
        """Получить сводку портфеля"""
        total_value = self.portfolio.available_usdt
        unrealized_pnl = 0
        
        for pos in self.portfolio.positions.values():
            position_value = pos.quantity * pos.current_price
            total_value += position_value
            unrealized_pnl += pos.unrealized_pnl
        
        return {
            'total_value': total_value,
            'available_usdt': self.portfolio.available_usdt,
            'unrealized_pnl': unrealized_pnl,
            'realized_pnl': self.portfolio.total_pnl,
            'total_pnl': unrealized_pnl + self.portfolio.total_pnl,
            'open_positions': len(self.portfolio.positions),
            'win_rate': self.portfolio.win_rate,
            'total_trades': self.portfolio.total_trades
        }

# ═══════════════════════════════════════════════════════════════════════════════
# TELEGRAM ADMIN HANDLERS
# ═══════════════════════════════════════════════════════════════════════════════

class TelegramAdmin:
    """Админ-панель в Telegram"""
    
    def __init__(self, bot: 'CryptoTradingBot'):
        self.bot = bot
        self.authenticated_users = set()
        self.application = None
    
    async def setup(self):
        """Настроить обработчики команд"""
        self.application = Application.builder().token(Config.TG_TOKEN).build()
        
        # Команды
        self.application.add_handler(CommandHandler("start", self.cmd_start))
        self.application.add_handler(CommandHandler("admin", self.cmd_admin))
        self.application.add_handler(CommandHandler("portfolio", self.cmd_portfolio))
        self.application.add_handler(CommandHandler("stats", self.cmd_stats))
        self.application.add_handler(CommandHandler("settings", self.cmd_settings))
        self.application.add_handler(CommandHandler("stoploss", self.cmd_stoploss))
        self.application.add_handler(CommandHandler("takeprofit", self.cmd_takeprofit))
        self.application.add_handler(CommandHandler("confidence", self.cmd_confidence))
        self.application.add_handler(CommandHandler("scaninterval", self.cmd_scaninterval))
        self.application.add_handler(CommandHandler("chat", self.cmd_chat))
        
        # Callbacks для кнопок
        self.application.add_handler(CallbackQueryHandler(self.on_callback))
        
        # Текстовые сообщения (для пароля)
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.on_message))
        
        # Запускаем
        asyncio.create_task(self.application.run_polling(allowed_updates=Update.ALL_TYPES))
    
    async def cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик /start"""
        await update.message.reply_text(
            "<b>Crypto Trading Bot</b>\n\n"
            "Используйте /admin для доступа к админ-панели\n"
            "Используйте /portfolio для просмотра портфеля\n"
            "Используйте /stats для статистики",
            parse_mode=ParseMode.HTML
        )
    
    async def cmd_admin(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработчик /admin"""
        user_id = update.effective_user.id
        
        if user_id in self.authenticated_users:
            await self.show_admin_panel(update)
        else:
            await update.message.reply_text(
                "<b>Авторизация</b>\n\nВведите пароль:",
                parse_mode=ParseMode.HTML
            )
            context.user_data['awaiting_password'] = True
    
    async def on_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка текстовых сообщений"""
        user_id = update.effective_user.id
        
        if context.user_data.get('awaiting_password'):
            password = update.message.text
            
            if password == Config.ADMIN_PASSWORD:
                self.authenticated_users.add(user_id)
                context.user_data['awaiting_password'] = False
                await update.message.reply_text("✅ Авторизация успешна!")
                await self.show_admin_panel(update)
            else:
                await update.message.reply_text("❌ Неверный пароль!")
            
            return
        
        if context.user_data.get('awaiting_chat_id'):
            chat_id = update.message.text
            Config.CHAT_ID = chat_id
            self.bot.telegram.chat_id = chat_id
            context.user_data['awaiting_chat_id'] = False
            await update.message.reply_text(f"✅ Chat ID обновлен: {chat_id}")
            return
    
    async def show_admin_panel(self, update: Update):
        """Показать админ-панель"""
        keyboard = [
            [InlineKeyboardButton("📊 Портфель", callback_data='portfolio')],
            [InlineKeyboardButton("📈 Статистика", callback_data='stats')],
            [InlineKeyboardButton("⚙️ Настройки", callback_data='settings')],
            [InlineKeyboardButton("💬 Сменить чат", callback_data='change_chat')],
        ]
        
        await update.message.reply_text(
            "<b>АДМИН-ПАНЕЛЬ</b>\n\n"
            f"Текущий чат: {Config.CHAT_ID}\n"
            f"Режим: {Config.TRADING_MODE}\n"
            f"Сигналов сегодня: {self.bot.signal_engine.signals_today}",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    
    async def cmd_portfolio(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать портфель"""
        summary = self.bot.portfolio_manager.get_summary()
        
        message = f"""<b>[PORTFOLIO] ПОРТФЕЛЬ</b>

Баланс: ${summary['total_value']:.2f}
Доступно: ${summary['available_usdt']:.2f}
P&L: ${summary['total_pnl']:+.2f}
Win Rate: {summary['win_rate']:.1f}%
Сделок: {summary['total_trades']}

Открытых позиций: {summary['open_positions']}"""
        
        await update.message.reply_text(message, parse_mode=ParseMode.HTML)
    
    async def cmd_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать статистику"""
        tg_stats = self.bot.telegram.get_stats()
        
        message = f"""<b>[STATS] СТАТИСТИКА БОТА</b>

<b>Сканирование:</b>
• Просканировано: {self.bot.scanned_count}
• Сигналов: {self.bot.signals_generated}
• Сегодня: {self.bot.signal_engine.signals_today}

<b>Telegram:</b>
• Отправлено: {tg_stats['sent']}
• Ошибок: {tg_stats['dropped']}
• В очереди: {tg_stats['queue_size']}

<b>Binance API:</b>
• Запросов: {self.bot.binance.request_count}

<b>Время работы:</b>
{self.bot.get_uptime()}"""
        
        await update.message.reply_text(message, parse_mode=ParseMode.HTML)
    
    async def cmd_settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Показать настройки"""
        message = f"""<b>[SETTINGS] НАСТРОЙКИ</b>

<b>Торговля:</b>
• Стоп-лосс: {Config.STOP_LOSS}%
• TP1: {Config.TAKE_PROFIT_1}%
• TP2: {Config.TAKE_PROFIT_2}%
• TP3: {Config.TAKE_PROFIT_3}%
• Макс позиция: ${Config.MAX_POSITION_SIZE}

<b>Сигналы:</b>
• Мин уверенность: {Config.MIN_CONFIDENCE}%
• Кулдаун: {Config.SIGNAL_COOLDOWN_HOURS}ч
• Интервал сканирования: {Config.SCAN_INTERVAL}с

<b>Команды для изменения:</b>
/stoploss [значение]
/takeprofit [значение]
/confidence [значение]
/scaninterval [значение]"""
        
        await update.message.reply_text(message, parse_mode=ParseMode.HTML)
    
    async def cmd_stoploss(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Изменить стоп-лосс"""
        try:
            value = float(context.args[0])
            Config.STOP_LOSS = value
            await update.message.reply_text(f"✅ Стоп-лосс изменен на {value}%")
        except:
            await update.message.reply_text("❌ Использование: /stoploss 5")
    
    async def cmd_takeprofit(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Изменить тейк-профит"""
        try:
            value = float(context.args[0])
            Config.TAKE_PROFIT_1 = value
            await update.message.reply_text(f"✅ TP1 изменен на {value}%")
        except:
            await update.message.reply_text("❌ Использование: /takeprofit 10")
    
    async def cmd_confidence(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Изменить минимальную уверенность"""
        try:
            value = int(context.args[0])
            Config.MIN_CONFIDENCE = value
            await update.message.reply_text(f"✅ Мин уверенность изменена на {value}%")
        except:
            await update.message.reply_text("❌ Использование: /confidence 75")
    
    async def cmd_scaninterval(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Изменить интервал сканирования"""
        try:
            value = int(context.args[0])
            Config.SCAN_INTERVAL = value
            await update.message.reply_text(f"✅ Интервал сканирования изменен на {value}с")
        except:
            await update.message.reply_text("❌ Использование: /scaninterval 60")
    
    async def cmd_chat(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Сменить чат для отправки"""
        await update.message.reply_text(
            "<b>Смена чата</b>\n\nВведите новый Chat ID:",
            parse_mode=ParseMode.HTML
        )
        context.user_data['awaiting_chat_id'] = True
    
    async def on_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Обработка кнопок"""
        query = update.callback_query
        await query.answer()
        
        if query.data == 'portfolio':
            await self.cmd_portfolio(update, context)
        elif query.data == 'stats':
            await self.cmd_stats(update, context)
        elif query.data == 'settings':
            await self.cmd_settings(update, context)
        elif query.data == 'change_chat':
            await self.cmd_chat(update, context)

# ═══════════════════════════════════════════════════════════════════════════════
# MAIN BOT
# ═══════════════════════════════════════════════════════════════════════════════

class CryptoTradingBot:
    """Главный класс торгового бота"""
    
    def __init__(self):
        self.binance = BinanceClient()
        self.signal_engine = SignalEngine()
        self.portfolio_manager = PortfolioManager()
        self.telegram = TelegramNotifier(Config.TG_TOKEN, Config.CHAT_ID)
        self.admin = TelegramAdmin(self)
        
        self.running = False
        self.scanned_count = 0
        self.signals_generated = 0
        self.start_time = None
        self.reconnect_attempts = 0
        self.max_reconnect_attempts = 10
    
    def get_uptime(self) -> str:
        """Получить время работы"""
        if not self.start_time:
            return "00:00:00"
        
        uptime = datetime.now() - self.start_time
        hours, remainder = divmod(int(uptime.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    
    async def start(self):
        """Запустить бота с вечным мониторингом"""
        self.running = True
        self.start_time = datetime.now()
        
        logger.info("=" * 60)
        logger.info("ULTIMATE CRYPTO TRADING BOT v2.0 ЗАПУЩЕН!")
        logger.info("=" * 60)
        
        # Запускаем Telegram
        await self.telegram.start()
        await self.telegram.send_startup_message()
        
        # Запускаем админ-панель
        await self.admin.setup()
        
        # Вечный цикл с переподключением
        while self.running:
            try:
                await self._main_loop()
            except Exception as e:
                self.reconnect_attempts += 1
                logger.error(f"Critical error (attempt {self.reconnect_attempts}): {e}")
                
                if self.reconnect_attempts >= self.max_reconnect_attempts:
                    logger.error("Max reconnect attempts reached. Stopping.")
                    await self.telegram.send_alert("CRITICAL", "Бот остановлен из-за ошибок")
                    break
                
                wait_time = min(60 * self.reconnect_attempts, 300)
                logger.info(f"Reconnecting in {wait_time} seconds...")
                await asyncio.sleep(wait_time)
    
    async def _main_loop(self):
        """Основной цикл работы"""
        
        # Запускаем задачи
        tasks = [
            self._scanning_loop(),
            self._portfolio_loop(),
            self._top_movers_loop(),
        ]
        
        await asyncio.gather(*tasks)
    
    async def _scanning_loop(self):
        """Основной цикл сканирования - только топ токены"""
        
        while self.running:
            try:
                logger.info("[SCAN] Начинаю сканирование рынка...")
                
                # Получаем все тикеры
                tickers = self.binance.get_all_tickers()
                
                # Фильтруем USDT пары с достаточным объемом
                usdt_pairs = [
                    t for t in tickers 
                    if t.get('symbol', '').endswith('USDT') and
                    float(t.get('quoteVolume', 0)) > Config.MIN_VOLUME_24H
                ]
                
                # Сортируем по объему
                usdt_pairs.sort(key=lambda x: float(x.get('quoteVolume', 0)), reverse=True)
                
                # Берем только топ-N + приоритетные
                top_pairs = usdt_pairs[:Config.TOP_TOKENS_COUNT]
                priority_symbols = set(Config.PRIORITY_TOKENS)
                
                # Добавляем приоритетные если их нет в топе
                for ticker in usdt_pairs[Config.TOP_TOKENS_COUNT:]:
                    if ticker['symbol'] in priority_symbols:
                        top_pairs.append(ticker)
                
                logger.info(f"[SCAN] Анализирую {len(top_pairs)} токенов")
                
                signals_this_scan = 0
                
                for ticker in top_pairs:
                    if not self.running:
                        break
                    
                    # Лимит сигналов за сканирование
                    if signals_this_scan >= Config.MAX_SIGNALS_PER_SCAN:
                        logger.info("[SCAN] Достигнут лимит сигналов за сканирование")
                        break
                    
                    symbol = ticker['symbol']
                    
                    try:
                        # Получаем свечи
                        klines = self.binance.get_klines(symbol, '1h', 100)
                        
                        if not klines or len(klines) < 50:
                            continue
                        
                        # Создаем данные токена
                        token_data = TokenData(
                            symbol=symbol,
                            name=symbol.replace('USDT', ''),
                            price=float(ticker.get('lastPrice', 0)),
                            price_change_24h=float(ticker.get('priceChangePercent', 0)),
                            volume_24h=float(ticker.get('quoteVolume', 0)),
                        )
                        
                        # Генерируем сигнал
                        signal = self.signal_engine.generate_signal(symbol, klines, token_data)
                        
                        if signal:
                            self.signals_generated += 1
                            signals_this_scan += 1
                            
                            # Отправляем в Telegram
                            await self.telegram.send_signal(signal)
                            
                            logger.info(f"[SIGNAL] {signal.signal_type.value} для {symbol} (уверенность: {signal.confidence}%)")
                        
                        self.scanned_count += 1
                        
                        # Небольшая задержка между запросами
                        await asyncio.sleep(0.1)
                        
                    except Exception as e:
                        logger.error(f"[ERROR] Анализ {symbol}: {e}")
                        continue
                
                logger.info(f"[SCAN] Завершено. Просканировано: {self.scanned_count}, Сигналов: {self.signals_generated}")
                
                # Ждем перед следующим сканированием
                await asyncio.sleep(Config.SCAN_INTERVAL)
                
            except Exception as e:
                logger.error(f"[ERROR] Ошибка в scanning loop: {e}")
                await asyncio.sleep(10)
    
    async def _portfolio_loop(self):
        """Цикл обновления портфеля"""
        
        while self.running:
            try:
                # Обновляем цены для открытых позиций
                if self.portfolio_manager.portfolio.positions:
                    prices = {}
                    for symbol in self.portfolio_manager.portfolio.positions.keys():
                        price = self.binance.get_ticker_price(symbol)
                        if price > 0:
                            prices[symbol] = price
                    
                    self.portfolio_manager.update_prices(prices)
                
                # Отправляем обновление каждые 30 минут
                if int(time.time()) % 1800 < 60:
                    await self.telegram.send_portfolio_update(
                        self.portfolio_manager.portfolio
                    )
                
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"[ERROR] Portfolio loop: {e}")
                await asyncio.sleep(10)
    
    async def _top_movers_loop(self):
        """Цикл отслеживания топ движений"""
        
        while self.running:
            try:
                # Отправляем раз в 3 часа
                if int(time.time()) % 10800 < 60:
                    tickers = self.binance.get_all_tickers()
                    usdt_pairs = [t for t in tickers if t.get('symbol', '').endswith('USDT')]
                    
                    # Топ растущих
                    gainers = sorted(
                        usdt_pairs, 
                        key=lambda x: float(x.get('priceChangePercent', 0)), 
                        reverse=True
                    )[:5]
                    
                    message = "<b>[MARKET] ТОП ДВИЖЕНИЯ 24Ч</b>\n\n"
                    
                    message += "<b>Рост:</b>\n"
                    for i, t in enumerate(gainers, 1):
                        sym = t['symbol'].replace('USDT', '')
                        pct = float(t.get('priceChangePercent', 0))
                        message += f"{i}. {sym}: +{pct:.2f}%\n"
                    
                    await self.telegram.message_queue.put(message)
                
                await asyncio.sleep(300)
                
            except Exception as e:
                logger.error(f"[ERROR] Top movers loop: {e}")
                await asyncio.sleep(60)
    
    def stop(self):
        """Остановить бота"""
        self.running = False
        logger.info("[STOP] Бот остановлен")

# ═══════════════════════════════════════════════════════════════════════════════
# ЗАПУСК
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    """Главная функция"""
    bot = CryptoTradingBot()
    
    try:
        await bot.start()
    except KeyboardInterrupt:
        logger.info("[EXIT] Получен сигнал остановки...")
        bot.stop()
    except Exception as e:
        logger.error(f"[FATAL] Critical error: {e}")
        bot.stop()

if __name__ == "__main__":
    print("""
╔═══════════════════════════════════════════════════════════════════════════════╗
║              CRYPTO TRADING BOT v2.0 - PRO                                    ║
║                                                                               ║
║  Улучшенная версия с:                                                         ║
║  • Админ-панелью в Telegram                                                   ║
║  • Rate limiting (защита от flood)                                            ║
║  • Умной фильтрацией сигналов                                                 ║
║  • Вечным мониторингом                                                        ║
╚═══════════════════════════════════════════════════════════════════════════════╝
""")
    
    asyncio.run(main())
